﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class DichVu_DTO
    {
        public string ID_The { get; set; }
        public string ID_CanHo { get; set; }
        public string TinhTrang { get; set; }
        public string LoaiThe { get; set; }
        public string LoaiXe { get; set; }
        public string BienSoXe { get; set; }
    }
}
