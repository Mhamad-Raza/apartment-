﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class HoaDon_DTO
    {
        public string ID_HoaDon { get; set; }
        public string ID_CanHo { get; set; }
        public string LoaiHoaDon { get; set; }
        public string TenHoaDon { get; set; }
        public string TongTien { get; set; }
        public string TrangThai { get; set; }
        public string NgayLapHoaDon { get; set; }





    }
}
