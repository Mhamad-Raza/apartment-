﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class KhoanPhi_DTO
    {
        public string ID_KhoanPhi { get; set; }
        public string TenKhoanPhi { get; set; }
        public decimal DonGia { get; set; }
        public string ChuKy { get; set; }
        public string TrangThai { get; set; }
    }
}
