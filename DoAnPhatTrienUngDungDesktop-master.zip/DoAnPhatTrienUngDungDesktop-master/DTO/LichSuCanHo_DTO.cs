﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class LichSuCanHo_DTO
    {
        public string ID_LichSuCanHo { get; set; }
        public string ID_CuDanSoHuu { get; set; }
        public string ID_CanHo { get; set; }
        public string NgayDangKySoHuu { get; set; }
        public string NgayKetThucSoHuu { get; set; }
    }
}
