﻿namespace Đồ_án_desktop_2._0
{
    partial class QuanLyDichVu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(QuanLyDichVu));
            this.guna2GradientPanel2 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.guna2GradientPanel6 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.guna2GradientPanel1 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.btn_TB = new Guna.UI2.WinForms.Guna2Button();
            this.btn_QLTK = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button8 = new Guna.UI2.WinForms.Guna2Button();
            this.btn_DangXuat = new Guna.UI2.WinForms.Guna2Button();
            this.btn_CSCD = new Guna.UI2.WinForms.Guna2Button();
            this.btn_QLTI = new Guna.UI2.WinForms.Guna2Button();
            this.btn_QLCP = new Guna.UI2.WinForms.Guna2Button();
            this.btn_QLCH = new Guna.UI2.WinForms.Guna2Button();
            this.btn_QLCDDD = new Guna.UI2.WinForms.Guna2Button();
            this.guna2GradientPanel8 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.guna2HtmlLabel4 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.txt_keyword = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.cbb_LoaiThe = new Guna.UI2.WinForms.Guna2ComboBox();
            this.dgv_DichVu = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.guna2GradientPanel5 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.btn_Refresh = new Guna.UI2.WinForms.Guna2Button();
            this.btn_TraCuu = new Guna.UI2.WinForms.Guna2Button();
            this.label2 = new System.Windows.Forms.Label();
            this.guna2GradientPanel3 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.btn_ChinhSua = new Guna.UI2.WinForms.Guna2Button();
            this.btn_Them = new Guna.UI2.WinForms.Guna2Button();
            this.btn_Xoa = new Guna.UI2.WinForms.Guna2Button();
            this.guna2PictureBox2 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2GradientPanel2.SuspendLayout();
            this.guna2GradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_DichVu)).BeginInit();
            this.guna2GradientPanel5.SuspendLayout();
            this.guna2GradientPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2GradientPanel2
            // 
            this.guna2GradientPanel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientPanel2.Controls.Add(this.guna2GradientPanel6);
            this.guna2GradientPanel2.FillColor = System.Drawing.Color.White;
            this.guna2GradientPanel2.FillColor2 = System.Drawing.Color.LightGray;
            this.guna2GradientPanel2.Location = new System.Drawing.Point(208, -1);
            this.guna2GradientPanel2.Name = "guna2GradientPanel2";
            this.guna2GradientPanel2.Size = new System.Drawing.Size(10, 700);
            this.guna2GradientPanel2.TabIndex = 66;
            // 
            // guna2GradientPanel6
            // 
            this.guna2GradientPanel6.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientPanel6.FillColor = System.Drawing.Color.Gainsboro;
            this.guna2GradientPanel6.FillColor2 = System.Drawing.Color.WhiteSmoke;
            this.guna2GradientPanel6.Location = new System.Drawing.Point(9, 232);
            this.guna2GradientPanel6.Name = "guna2GradientPanel6";
            this.guna2GradientPanel6.Size = new System.Drawing.Size(1089, 5);
            this.guna2GradientPanel6.TabIndex = 52;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DimGray;
            this.label1.Location = new System.Drawing.Point(281, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(222, 26);
            this.label1.TabIndex = 54;
            this.label1.Text = "QUẢN LÝ DỊCH VỤ";
            // 
            // guna2GradientPanel1
            // 
            this.guna2GradientPanel1.BackColor = System.Drawing.Color.White;
            this.guna2GradientPanel1.Controls.Add(this.btn_TB);
            this.guna2GradientPanel1.Controls.Add(this.btn_QLTK);
            this.guna2GradientPanel1.Controls.Add(this.guna2Button8);
            this.guna2GradientPanel1.Controls.Add(this.btn_DangXuat);
            this.guna2GradientPanel1.Controls.Add(this.btn_CSCD);
            this.guna2GradientPanel1.Controls.Add(this.btn_QLTI);
            this.guna2GradientPanel1.Controls.Add(this.btn_QLCP);
            this.guna2GradientPanel1.Controls.Add(this.btn_QLCH);
            this.guna2GradientPanel1.Controls.Add(this.btn_QLCDDD);
            this.guna2GradientPanel1.Location = new System.Drawing.Point(-2, -1);
            this.guna2GradientPanel1.Name = "guna2GradientPanel1";
            this.guna2GradientPanel1.Size = new System.Drawing.Size(211, 701);
            this.guna2GradientPanel1.TabIndex = 128;
            // 
            // btn_TB
            // 
            this.btn_TB.BackColor = System.Drawing.Color.Transparent;
            this.btn_TB.BorderColor = System.Drawing.Color.Transparent;
            this.btn_TB.BorderThickness = 1;
            this.btn_TB.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_TB.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_TB.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_TB.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_TB.FillColor = System.Drawing.Color.Transparent;
            this.btn_TB.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_TB.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_TB.Image = ((System.Drawing.Image)(resources.GetObject("btn_TB.Image")));
            this.btn_TB.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_TB.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_TB.Location = new System.Drawing.Point(2, 358);
            this.btn_TB.Name = "btn_TB";
            this.btn_TB.Size = new System.Drawing.Size(213, 50);
            this.btn_TB.TabIndex = 10;
            this.btn_TB.Text = "Thông báo";
            this.btn_TB.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_TB.Click += new System.EventHandler(this.btn_TB_Click);
            // 
            // btn_QLTK
            // 
            this.btn_QLTK.BackColor = System.Drawing.Color.Transparent;
            this.btn_QLTK.BorderColor = System.Drawing.Color.Transparent;
            this.btn_QLTK.BorderThickness = 1;
            this.btn_QLTK.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLTK.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLTK.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_QLTK.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_QLTK.FillColor = System.Drawing.Color.Transparent;
            this.btn_QLTK.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_QLTK.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_QLTK.Image = ((System.Drawing.Image)(resources.GetObject("btn_QLTK.Image")));
            this.btn_QLTK.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLTK.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_QLTK.Location = new System.Drawing.Point(2, 205);
            this.btn_QLTK.Name = "btn_QLTK";
            this.btn_QLTK.Size = new System.Drawing.Size(213, 50);
            this.btn_QLTK.TabIndex = 9;
            this.btn_QLTK.Text = "Quản lý tài khoản";
            this.btn_QLTK.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLTK.Click += new System.EventHandler(this.btn_QLTK_Click);
            // 
            // guna2Button8
            // 
            this.guna2Button8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2Button8.BorderColor = System.Drawing.Color.Transparent;
            this.guna2Button8.BorderThickness = 1;
            this.guna2Button8.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button8.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button8.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button8.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button8.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button8.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.guna2Button8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.guna2Button8.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button8.Image")));
            this.guna2Button8.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button8.ImageSize = new System.Drawing.Size(30, 30);
            this.guna2Button8.Location = new System.Drawing.Point(2, 103);
            this.guna2Button8.Name = "guna2Button8";
            this.guna2Button8.Size = new System.Drawing.Size(213, 50);
            this.guna2Button8.TabIndex = 8;
            this.guna2Button8.Text = "Quản lý dịch vụ";
            this.guna2Button8.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // btn_DangXuat
            // 
            this.btn_DangXuat.BackColor = System.Drawing.Color.Transparent;
            this.btn_DangXuat.BorderColor = System.Drawing.Color.Transparent;
            this.btn_DangXuat.BorderThickness = 2;
            this.btn_DangXuat.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_DangXuat.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_DangXuat.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_DangXuat.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_DangXuat.FillColor = System.Drawing.Color.Transparent;
            this.btn_DangXuat.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_DangXuat.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_DangXuat.Image = ((System.Drawing.Image)(resources.GetObject("btn_DangXuat.Image")));
            this.btn_DangXuat.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_DangXuat.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_DangXuat.Location = new System.Drawing.Point(-2, 658);
            this.btn_DangXuat.Name = "btn_DangXuat";
            this.btn_DangXuat.Size = new System.Drawing.Size(213, 41);
            this.btn_DangXuat.TabIndex = 7;
            this.btn_DangXuat.Text = "Đăng xuất";
            this.btn_DangXuat.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_DangXuat.Click += new System.EventHandler(this.btn_DangXuat_Click);
            // 
            // btn_CSCD
            // 
            this.btn_CSCD.BackColor = System.Drawing.Color.Transparent;
            this.btn_CSCD.BorderColor = System.Drawing.Color.Transparent;
            this.btn_CSCD.BorderThickness = 1;
            this.btn_CSCD.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_CSCD.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_CSCD.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_CSCD.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_CSCD.FillColor = System.Drawing.Color.Transparent;
            this.btn_CSCD.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_CSCD.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_CSCD.Image = ((System.Drawing.Image)(resources.GetObject("btn_CSCD.Image")));
            this.btn_CSCD.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_CSCD.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_CSCD.Location = new System.Drawing.Point(2, 1);
            this.btn_CSCD.Name = "btn_CSCD";
            this.btn_CSCD.Size = new System.Drawing.Size(213, 50);
            this.btn_CSCD.TabIndex = 1;
            this.btn_CSCD.Text = "Chăm sóc cư dân";
            this.btn_CSCD.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_CSCD.Click += new System.EventHandler(this.btn_CSCD_Click);
            // 
            // btn_QLTI
            // 
            this.btn_QLTI.BackColor = System.Drawing.Color.Transparent;
            this.btn_QLTI.BorderColor = System.Drawing.Color.Transparent;
            this.btn_QLTI.BorderThickness = 1;
            this.btn_QLTI.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLTI.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLTI.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_QLTI.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_QLTI.FillColor = System.Drawing.Color.Transparent;
            this.btn_QLTI.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_QLTI.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_QLTI.Image = ((System.Drawing.Image)(resources.GetObject("btn_QLTI.Image")));
            this.btn_QLTI.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLTI.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_QLTI.Location = new System.Drawing.Point(2, 52);
            this.btn_QLTI.Name = "btn_QLTI";
            this.btn_QLTI.Size = new System.Drawing.Size(213, 50);
            this.btn_QLTI.TabIndex = 2;
            this.btn_QLTI.Text = "Quản lý tiện ích";
            this.btn_QLTI.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLTI.Click += new System.EventHandler(this.btn_QLTI_Click);
            // 
            // btn_QLCP
            // 
            this.btn_QLCP.BackColor = System.Drawing.Color.Transparent;
            this.btn_QLCP.BorderColor = System.Drawing.Color.Transparent;
            this.btn_QLCP.BorderThickness = 1;
            this.btn_QLCP.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLCP.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLCP.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_QLCP.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_QLCP.FillColor = System.Drawing.Color.Transparent;
            this.btn_QLCP.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_QLCP.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_QLCP.Image = ((System.Drawing.Image)(resources.GetObject("btn_QLCP.Image")));
            this.btn_QLCP.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLCP.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_QLCP.Location = new System.Drawing.Point(2, 307);
            this.btn_QLCP.Name = "btn_QLCP";
            this.btn_QLCP.Size = new System.Drawing.Size(213, 50);
            this.btn_QLCP.TabIndex = 5;
            this.btn_QLCP.Text = "Quản lý khoản phí";
            this.btn_QLCP.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLCP.Click += new System.EventHandler(this.btn_QLCP_Click);
            // 
            // btn_QLCH
            // 
            this.btn_QLCH.BackColor = System.Drawing.Color.Transparent;
            this.btn_QLCH.BorderColor = System.Drawing.Color.Transparent;
            this.btn_QLCH.BorderThickness = 1;
            this.btn_QLCH.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLCH.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLCH.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_QLCH.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_QLCH.FillColor = System.Drawing.Color.Transparent;
            this.btn_QLCH.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_QLCH.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_QLCH.Image = ((System.Drawing.Image)(resources.GetObject("btn_QLCH.Image")));
            this.btn_QLCH.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLCH.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_QLCH.Location = new System.Drawing.Point(2, 154);
            this.btn_QLCH.Name = "btn_QLCH";
            this.btn_QLCH.Size = new System.Drawing.Size(213, 50);
            this.btn_QLCH.TabIndex = 3;
            this.btn_QLCH.Text = "Quản lý căn hộ";
            this.btn_QLCH.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLCH.Click += new System.EventHandler(this.btn_QLCH_Click);
            // 
            // btn_QLCDDD
            // 
            this.btn_QLCDDD.BackColor = System.Drawing.Color.Transparent;
            this.btn_QLCDDD.BorderColor = System.Drawing.Color.Transparent;
            this.btn_QLCDDD.BorderThickness = 1;
            this.btn_QLCDDD.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLCDDD.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLCDDD.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_QLCDDD.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_QLCDDD.FillColor = System.Drawing.Color.Transparent;
            this.btn_QLCDDD.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_QLCDDD.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_QLCDDD.Image = ((System.Drawing.Image)(resources.GetObject("btn_QLCDDD.Image")));
            this.btn_QLCDDD.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLCDDD.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_QLCDDD.Location = new System.Drawing.Point(2, 256);
            this.btn_QLCDDD.Name = "btn_QLCDDD";
            this.btn_QLCDDD.Size = new System.Drawing.Size(213, 50);
            this.btn_QLCDDD.TabIndex = 4;
            this.btn_QLCDDD.Text = "Quản lý cư dân đại diện";
            this.btn_QLCDDD.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLCDDD.Click += new System.EventHandler(this.btn_QLCDDD_Click);
            // 
            // guna2GradientPanel8
            // 
            this.guna2GradientPanel8.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientPanel8.FillColor = System.Drawing.Color.Gainsboro;
            this.guna2GradientPanel8.FillColor2 = System.Drawing.Color.WhiteSmoke;
            this.guna2GradientPanel8.Location = new System.Drawing.Point(211, 229);
            this.guna2GradientPanel8.Name = "guna2GradientPanel8";
            this.guna2GradientPanel8.Size = new System.Drawing.Size(1098, 5);
            this.guna2GradientPanel8.TabIndex = 166;
            // 
            // guna2HtmlLabel4
            // 
            this.guna2HtmlLabel4.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2HtmlLabel4.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel4.Location = new System.Drawing.Point(18, 85);
            this.guna2HtmlLabel4.Name = "guna2HtmlLabel4";
            this.guna2HtmlLabel4.Padding = new System.Windows.Forms.Padding(5);
            this.guna2HtmlLabel4.Size = new System.Drawing.Size(122, 37);
            this.guna2HtmlLabel4.TabIndex = 164;
            this.guna2HtmlLabel4.Text = "Nhập từ khóa";
            // 
            // txt_keyword
            // 
            this.txt_keyword.BorderRadius = 10;
            this.txt_keyword.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_keyword.DefaultText = "";
            this.txt_keyword.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_keyword.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_keyword.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_keyword.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_keyword.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_keyword.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txt_keyword.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_keyword.Location = new System.Drawing.Point(892, 152);
            this.txt_keyword.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_keyword.Name = "txt_keyword";
            this.txt_keyword.PasswordChar = '\0';
            this.txt_keyword.PlaceholderText = "";
            this.txt_keyword.SelectedText = "";
            this.txt_keyword.Size = new System.Drawing.Size(237, 36);
            this.txt_keyword.TabIndex = 161;
            // 
            // guna2HtmlLabel2
            // 
            this.guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2HtmlLabel2.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel2.Location = new System.Drawing.Point(65, 32);
            this.guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            this.guna2HtmlLabel2.Padding = new System.Windows.Forms.Padding(5);
            this.guna2HtmlLabel2.Size = new System.Drawing.Size(75, 37);
            this.guna2HtmlLabel2.TabIndex = 162;
            this.guna2HtmlLabel2.Text = "Loại thẻ";
            // 
            // cbb_LoaiThe
            // 
            this.cbb_LoaiThe.BackColor = System.Drawing.Color.Transparent;
            this.cbb_LoaiThe.BorderRadius = 10;
            this.cbb_LoaiThe.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cbb_LoaiThe.DropDownHeight = 90;
            this.cbb_LoaiThe.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbb_LoaiThe.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbb_LoaiThe.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbb_LoaiThe.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbb_LoaiThe.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cbb_LoaiThe.IntegralHeight = false;
            this.cbb_LoaiThe.ItemHeight = 30;
            this.cbb_LoaiThe.Items.AddRange(new object[] {
            "Thẻ thang máy",
            "Thẻ nhà",
            "Thẻ xe"});
            this.cbb_LoaiThe.Location = new System.Drawing.Point(146, 32);
            this.cbb_LoaiThe.Name = "cbb_LoaiThe";
            this.cbb_LoaiThe.Size = new System.Drawing.Size(237, 36);
            this.cbb_LoaiThe.TabIndex = 163;
            // 
            // dgv_DichVu
            // 
            this.dgv_DichVu.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_DichVu.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgv_DichVu.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgv_DichVu.ColumnHeadersHeight = 40;
            this.dgv_DichVu.Location = new System.Drawing.Point(219, 233);
            this.dgv_DichVu.Name = "dgv_DichVu";
            this.dgv_DichVu.RowHeadersWidth = 82;
            this.dgv_DichVu.RowTemplate.Height = 28;
            this.dgv_DichVu.Size = new System.Drawing.Size(1091, 468);
            this.dgv_DichVu.TabIndex = 153;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DimGray;
            this.label3.Location = new System.Drawing.Point(768, 54);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(125, 29);
            this.label3.TabIndex = 160;
            this.label3.Text = "TRA CỨU";
            // 
            // guna2GradientPanel5
            // 
            this.guna2GradientPanel5.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientPanel5.BorderColor = System.Drawing.Color.Silver;
            this.guna2GradientPanel5.BorderRadius = 10;
            this.guna2GradientPanel5.BorderThickness = 2;
            this.guna2GradientPanel5.Controls.Add(this.btn_Refresh);
            this.guna2GradientPanel5.Controls.Add(this.guna2HtmlLabel2);
            this.guna2GradientPanel5.Controls.Add(this.btn_TraCuu);
            this.guna2GradientPanel5.Controls.Add(this.guna2HtmlLabel4);
            this.guna2GradientPanel5.Controls.Add(this.cbb_LoaiThe);
            this.guna2GradientPanel5.Location = new System.Drawing.Point(747, 68);
            this.guna2GradientPanel5.Name = "guna2GradientPanel5";
            this.guna2GradientPanel5.Size = new System.Drawing.Size(559, 147);
            this.guna2GradientPanel5.TabIndex = 165;
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Refresh.BackgroundImage")));
            this.btn_Refresh.BorderRadius = 10;
            this.btn_Refresh.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_Refresh.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_Refresh.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_Refresh.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_Refresh.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Refresh.ForeColor = System.Drawing.Color.Violet;
            this.btn_Refresh.Image = ((System.Drawing.Image)(resources.GetObject("btn_Refresh.Image")));
            this.btn_Refresh.IndicateFocus = true;
            this.btn_Refresh.Location = new System.Drawing.Point(474, 32);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(68, 92);
            this.btn_Refresh.TabIndex = 32;
            this.btn_Refresh.Click += new System.EventHandler(this.btn_Refresh_Click);
            // 
            // btn_TraCuu
            // 
            this.btn_TraCuu.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_TraCuu.BackgroundImage")));
            this.btn_TraCuu.BorderRadius = 10;
            this.btn_TraCuu.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_TraCuu.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_TraCuu.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_TraCuu.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_TraCuu.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_TraCuu.ForeColor = System.Drawing.Color.Violet;
            this.btn_TraCuu.Image = ((System.Drawing.Image)(resources.GetObject("btn_TraCuu.Image")));
            this.btn_TraCuu.IndicateFocus = true;
            this.btn_TraCuu.Location = new System.Drawing.Point(400, 32);
            this.btn_TraCuu.Name = "btn_TraCuu";
            this.btn_TraCuu.Size = new System.Drawing.Size(68, 92);
            this.btn_TraCuu.TabIndex = 31;
            this.btn_TraCuu.Click += new System.EventHandler(this.btn_TraCuu_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DimGray;
            this.label2.Location = new System.Drawing.Point(265, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(229, 29);
            this.label2.TabIndex = 154;
            this.label2.Text = "THAO TÁC CHÍNH";
            // 
            // guna2GradientPanel3
            // 
            this.guna2GradientPanel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientPanel3.BorderColor = System.Drawing.Color.Silver;
            this.guna2GradientPanel3.BorderRadius = 10;
            this.guna2GradientPanel3.BorderThickness = 2;
            this.guna2GradientPanel3.Controls.Add(this.btn_ChinhSua);
            this.guna2GradientPanel3.Controls.Add(this.btn_Them);
            this.guna2GradientPanel3.Controls.Add(this.btn_Xoa);
            this.guna2GradientPanel3.Location = new System.Drawing.Point(252, 68);
            this.guna2GradientPanel3.Name = "guna2GradientPanel3";
            this.guna2GradientPanel3.Size = new System.Drawing.Size(478, 147);
            this.guna2GradientPanel3.TabIndex = 155;
            // 
            // btn_ChinhSua
            // 
            this.btn_ChinhSua.BorderRadius = 10;
            this.btn_ChinhSua.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_ChinhSua.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_ChinhSua.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_ChinhSua.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_ChinhSua.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ChinhSua.ForeColor = System.Drawing.Color.White;
            this.btn_ChinhSua.Location = new System.Drawing.Point(181, 38);
            this.btn_ChinhSua.Name = "btn_ChinhSua";
            this.btn_ChinhSua.Size = new System.Drawing.Size(116, 70);
            this.btn_ChinhSua.TabIndex = 15;
            this.btn_ChinhSua.Text = "Sửa";
            this.btn_ChinhSua.Click += new System.EventHandler(this.btn_Sua_Click);
            // 
            // btn_Them
            // 
            this.btn_Them.BorderRadius = 10;
            this.btn_Them.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_Them.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_Them.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_Them.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_Them.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Them.ForeColor = System.Drawing.Color.White;
            this.btn_Them.Location = new System.Drawing.Point(35, 38);
            this.btn_Them.Name = "btn_Them";
            this.btn_Them.Size = new System.Drawing.Size(116, 70);
            this.btn_Them.TabIndex = 14;
            this.btn_Them.Text = "Thêm";
            this.btn_Them.Click += new System.EventHandler(this.btn_Them_Click);
            // 
            // btn_Xoa
            // 
            this.btn_Xoa.BorderRadius = 10;
            this.btn_Xoa.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_Xoa.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_Xoa.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_Xoa.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_Xoa.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btn_Xoa.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Xoa.ForeColor = System.Drawing.Color.White;
            this.btn_Xoa.Location = new System.Drawing.Point(327, 38);
            this.btn_Xoa.Name = "btn_Xoa";
            this.btn_Xoa.Size = new System.Drawing.Size(116, 70);
            this.btn_Xoa.TabIndex = 16;
            this.btn_Xoa.Text = "Xóa";
            this.btn_Xoa.Click += new System.EventHandler(this.btn_Xoa_Click);
            // 
            // guna2PictureBox2
            // 
            this.guna2PictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox2.ErrorImage = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox2.ErrorImage")));
            this.guna2PictureBox2.Image = global::ĐỒ_ÁN.Properties.Resources.logo;
            this.guna2PictureBox2.ImageRotate = 0F;
            this.guna2PictureBox2.Location = new System.Drawing.Point(219, 0);
            this.guna2PictureBox2.Name = "guna2PictureBox2";
            this.guna2PictureBox2.Size = new System.Drawing.Size(60, 38);
            this.guna2PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox2.TabIndex = 85;
            this.guna2PictureBox2.TabStop = false;
            // 
            // QuanLyDichVu
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.ClientSize = new System.Drawing.Size(1311, 699);
            this.Controls.Add(this.guna2PictureBox2);
            this.Controls.Add(this.guna2GradientPanel8);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.guna2GradientPanel1);
            this.Controls.Add(this.guna2GradientPanel2);
            this.Controls.Add(this.txt_keyword);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgv_DichVu);
            this.Controls.Add(this.guna2GradientPanel3);
            this.Controls.Add(this.guna2GradientPanel5);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "QuanLyDichVu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "QuanLyDichVu";
            this.Load += new System.EventHandler(this.QuanLyDichVu_Load);
            this.guna2GradientPanel2.ResumeLayout(false);
            this.guna2GradientPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_DichVu)).EndInit();
            this.guna2GradientPanel5.ResumeLayout(false);
            this.guna2GradientPanel5.PerformLayout();
            this.guna2GradientPanel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel2;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel6;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel1;
        private Guna.UI2.WinForms.Guna2Button btn_TB;
        private Guna.UI2.WinForms.Guna2Button btn_QLTK;
        private Guna.UI2.WinForms.Guna2Button guna2Button8;
        private Guna.UI2.WinForms.Guna2Button btn_DangXuat;
        private Guna.UI2.WinForms.Guna2Button btn_CSCD;
        private Guna.UI2.WinForms.Guna2Button btn_QLTI;
        private Guna.UI2.WinForms.Guna2Button btn_QLCP;
        private Guna.UI2.WinForms.Guna2Button btn_QLCH;
        private Guna.UI2.WinForms.Guna2Button btn_QLCDDD;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel8;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel4;
        private Guna.UI2.WinForms.Guna2TextBox txt_keyword;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2ComboBox cbb_LoaiThe;
        private System.Windows.Forms.DataGridView dgv_DichVu;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel5;
        private Guna.UI2.WinForms.Guna2Button btn_Refresh;
        private Guna.UI2.WinForms.Guna2Button btn_TraCuu;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel3;
        private Guna.UI2.WinForms.Guna2Button btn_ChinhSua;
        private Guna.UI2.WinForms.Guna2Button btn_Them;
        private Guna.UI2.WinForms.Guna2Button btn_Xoa;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox2;
    }
}