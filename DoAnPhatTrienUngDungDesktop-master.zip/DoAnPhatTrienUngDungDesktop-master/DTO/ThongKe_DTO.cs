﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class ThongKe_DTO
    {
        public string ID_ThongKe { get; set; }
        public string KhoanPhi { get; set; }
        public string ID_CanHo { get; set; }
        public string SoLuong { get; set; }
        public string TrangThai { get; set; }
    }
}
