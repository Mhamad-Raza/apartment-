﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class TienIch_DTO
    {
        public string ID_TienIch { get; set; }
        public string TenTienIch { get; set; }
        public string GioMo { get; set; }
        public string GioDong { get; set; }
        public string MoTa { get; set; }
        public decimal GiaTien { get; set; }
    }
}
