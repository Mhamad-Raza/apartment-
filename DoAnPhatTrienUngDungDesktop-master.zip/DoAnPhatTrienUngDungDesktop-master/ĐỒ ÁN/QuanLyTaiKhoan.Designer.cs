﻿namespace Đồ_án_desktop_2._0
{
    partial class QuanLyTaiKhoan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(QuanLyTaiKhoan));
            this.guna2GradientPanel8 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.guna2GradientPanel2 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.guna2GradientPanel6 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.guna2GradientPanel3 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.btn_ChinhSua = new Guna.UI2.WinForms.Guna2Button();
            this.btn_Them = new Guna.UI2.WinForms.Guna2Button();
            this.dgv_TaiKhoan = new System.Windows.Forms.DataGridView();
            this.guna2PictureBox2 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2GradientPanel1 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.btn_TB = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button12 = new Guna.UI2.WinForms.Guna2Button();
            this.btn_QLDV = new Guna.UI2.WinForms.Guna2Button();
            this.btn_DangXuat = new Guna.UI2.WinForms.Guna2Button();
            this.btn_CSCD = new Guna.UI2.WinForms.Guna2Button();
            this.btn_QLTI = new Guna.UI2.WinForms.Guna2Button();
            this.btn_QLCP = new Guna.UI2.WinForms.Guna2Button();
            this.btn_QLCH = new Guna.UI2.WinForms.Guna2Button();
            this.btn_QLCDDD = new Guna.UI2.WinForms.Guna2Button();
            this.guna2GradientPanel2.SuspendLayout();
            this.guna2GradientPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_TaiKhoan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox2)).BeginInit();
            this.guna2GradientPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2GradientPanel8
            // 
            this.guna2GradientPanel8.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientPanel8.FillColor = System.Drawing.Color.Gainsboro;
            this.guna2GradientPanel8.FillColor2 = System.Drawing.Color.WhiteSmoke;
            this.guna2GradientPanel8.Location = new System.Drawing.Point(217, 168);
            this.guna2GradientPanel8.Name = "guna2GradientPanel8";
            this.guna2GradientPanel8.Size = new System.Drawing.Size(1089, 5);
            this.guna2GradientPanel8.TabIndex = 83;
            // 
            // guna2GradientPanel2
            // 
            this.guna2GradientPanel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientPanel2.Controls.Add(this.guna2GradientPanel6);
            this.guna2GradientPanel2.FillColor = System.Drawing.Color.White;
            this.guna2GradientPanel2.FillColor2 = System.Drawing.Color.LightGray;
            this.guna2GradientPanel2.Location = new System.Drawing.Point(208, -1);
            this.guna2GradientPanel2.Name = "guna2GradientPanel2";
            this.guna2GradientPanel2.Size = new System.Drawing.Size(10, 700);
            this.guna2GradientPanel2.TabIndex = 82;
            // 
            // guna2GradientPanel6
            // 
            this.guna2GradientPanel6.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientPanel6.FillColor = System.Drawing.Color.Gainsboro;
            this.guna2GradientPanel6.FillColor2 = System.Drawing.Color.WhiteSmoke;
            this.guna2GradientPanel6.Location = new System.Drawing.Point(9, 232);
            this.guna2GradientPanel6.Name = "guna2GradientPanel6";
            this.guna2GradientPanel6.Size = new System.Drawing.Size(1089, 5);
            this.guna2GradientPanel6.TabIndex = 52;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DimGray;
            this.label1.Location = new System.Drawing.Point(265, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(251, 26);
            this.label1.TabIndex = 70;
            this.label1.Text = "QUẢN LÝ TÀI KHOẢN";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DimGray;
            this.label2.Location = new System.Drawing.Point(265, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(229, 29);
            this.label2.TabIndex = 71;
            this.label2.Text = "THAO TÁC CHÍNH";
            // 
            // guna2GradientPanel3
            // 
            this.guna2GradientPanel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientPanel3.BorderColor = System.Drawing.Color.Silver;
            this.guna2GradientPanel3.BorderRadius = 10;
            this.guna2GradientPanel3.BorderThickness = 2;
            this.guna2GradientPanel3.Controls.Add(this.btn_ChinhSua);
            this.guna2GradientPanel3.Controls.Add(this.btn_Them);
            this.guna2GradientPanel3.Location = new System.Drawing.Point(252, 68);
            this.guna2GradientPanel3.Name = "guna2GradientPanel3";
            this.guna2GradientPanel3.Size = new System.Drawing.Size(503, 88);
            this.guna2GradientPanel3.TabIndex = 72;
            // 
            // btn_ChinhSua
            // 
            this.btn_ChinhSua.BorderRadius = 10;
            this.btn_ChinhSua.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_ChinhSua.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_ChinhSua.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_ChinhSua.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_ChinhSua.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ChinhSua.ForeColor = System.Drawing.Color.White;
            this.btn_ChinhSua.Location = new System.Drawing.Point(278, 24);
            this.btn_ChinhSua.Name = "btn_ChinhSua";
            this.btn_ChinhSua.Size = new System.Drawing.Size(167, 47);
            this.btn_ChinhSua.TabIndex = 11;
            this.btn_ChinhSua.Text = "Sửa";
            this.btn_ChinhSua.Click += new System.EventHandler(this.btn_ChinhSua_Click);
            // 
            // btn_Them
            // 
            this.btn_Them.BorderRadius = 10;
            this.btn_Them.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_Them.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_Them.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_Them.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_Them.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Them.ForeColor = System.Drawing.Color.White;
            this.btn_Them.Location = new System.Drawing.Point(44, 24);
            this.btn_Them.Name = "btn_Them";
            this.btn_Them.Size = new System.Drawing.Size(167, 47);
            this.btn_Them.TabIndex = 10;
            this.btn_Them.Text = "Thêm";
            this.btn_Them.Click += new System.EventHandler(this.btn_Them_Click);
            // 
            // dgv_TaiKhoan
            // 
            this.dgv_TaiKhoan.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_TaiKhoan.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgv_TaiKhoan.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgv_TaiKhoan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_TaiKhoan.Location = new System.Drawing.Point(215, 171);
            this.dgv_TaiKhoan.Name = "dgv_TaiKhoan";
            this.dgv_TaiKhoan.RowHeadersWidth = 62;
            this.dgv_TaiKhoan.RowTemplate.Height = 28;
            this.dgv_TaiKhoan.Size = new System.Drawing.Size(1091, 528);
            this.dgv_TaiKhoan.TabIndex = 85;
            // 
            // guna2PictureBox2
            // 
            this.guna2PictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox2.ErrorImage = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox2.ErrorImage")));
            this.guna2PictureBox2.Image = global::ĐỒ_ÁN.Properties.Resources.logo;
            this.guna2PictureBox2.ImageRotate = 0F;
            this.guna2PictureBox2.Location = new System.Drawing.Point(215, 7);
            this.guna2PictureBox2.Name = "guna2PictureBox2";
            this.guna2PictureBox2.Size = new System.Drawing.Size(60, 38);
            this.guna2PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox2.TabIndex = 84;
            this.guna2PictureBox2.TabStop = false;
            // 
            // guna2GradientPanel1
            // 
            this.guna2GradientPanel1.BackColor = System.Drawing.Color.White;
            this.guna2GradientPanel1.Controls.Add(this.btn_TB);
            this.guna2GradientPanel1.Controls.Add(this.guna2Button12);
            this.guna2GradientPanel1.Controls.Add(this.btn_QLDV);
            this.guna2GradientPanel1.Controls.Add(this.btn_DangXuat);
            this.guna2GradientPanel1.Controls.Add(this.btn_CSCD);
            this.guna2GradientPanel1.Controls.Add(this.btn_QLTI);
            this.guna2GradientPanel1.Controls.Add(this.btn_QLCP);
            this.guna2GradientPanel1.Controls.Add(this.btn_QLCH);
            this.guna2GradientPanel1.Controls.Add(this.btn_QLCDDD);
            this.guna2GradientPanel1.Location = new System.Drawing.Point(-2, -1);
            this.guna2GradientPanel1.Name = "guna2GradientPanel1";
            this.guna2GradientPanel1.Size = new System.Drawing.Size(211, 701);
            this.guna2GradientPanel1.TabIndex = 128;
            // 
            // btn_TB
            // 
            this.btn_TB.BackColor = System.Drawing.Color.Transparent;
            this.btn_TB.BorderColor = System.Drawing.Color.Transparent;
            this.btn_TB.BorderThickness = 1;
            this.btn_TB.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_TB.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_TB.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_TB.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_TB.FillColor = System.Drawing.Color.Transparent;
            this.btn_TB.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_TB.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_TB.Image = ((System.Drawing.Image)(resources.GetObject("btn_TB.Image")));
            this.btn_TB.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_TB.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_TB.Location = new System.Drawing.Point(1, 353);
            this.btn_TB.Name = "btn_TB";
            this.btn_TB.Size = new System.Drawing.Size(213, 50);
            this.btn_TB.TabIndex = 10;
            this.btn_TB.Text = "Thông báo";
            this.btn_TB.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_TB.Click += new System.EventHandler(this.btn_TB_Click);
            // 
            // guna2Button12
            // 
            this.guna2Button12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2Button12.BorderColor = System.Drawing.Color.Transparent;
            this.guna2Button12.BorderThickness = 1;
            this.guna2Button12.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button12.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button12.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button12.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button12.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button12.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.guna2Button12.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.guna2Button12.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button12.Image")));
            this.guna2Button12.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button12.ImageSize = new System.Drawing.Size(30, 30);
            this.guna2Button12.Location = new System.Drawing.Point(1, 203);
            this.guna2Button12.Name = "guna2Button12";
            this.guna2Button12.Size = new System.Drawing.Size(213, 50);
            this.guna2Button12.TabIndex = 9;
            this.guna2Button12.Text = "Quản lý tài khoản";
            this.guna2Button12.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // btn_QLDV
            // 
            this.btn_QLDV.BackColor = System.Drawing.Color.Transparent;
            this.btn_QLDV.BorderColor = System.Drawing.Color.Transparent;
            this.btn_QLDV.BorderThickness = 1;
            this.btn_QLDV.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLDV.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLDV.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_QLDV.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_QLDV.FillColor = System.Drawing.Color.Transparent;
            this.btn_QLDV.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_QLDV.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_QLDV.Image = ((System.Drawing.Image)(resources.GetObject("btn_QLDV.Image")));
            this.btn_QLDV.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLDV.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_QLDV.Location = new System.Drawing.Point(1, 103);
            this.btn_QLDV.Name = "btn_QLDV";
            this.btn_QLDV.Size = new System.Drawing.Size(213, 50);
            this.btn_QLDV.TabIndex = 8;
            this.btn_QLDV.Text = "Quản lý dịch vụ";
            this.btn_QLDV.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLDV.Click += new System.EventHandler(this.btn_QLDV_Click);
            // 
            // btn_DangXuat
            // 
            this.btn_DangXuat.BackColor = System.Drawing.Color.Transparent;
            this.btn_DangXuat.BorderColor = System.Drawing.Color.Transparent;
            this.btn_DangXuat.BorderThickness = 2;
            this.btn_DangXuat.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_DangXuat.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_DangXuat.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_DangXuat.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_DangXuat.FillColor = System.Drawing.Color.Transparent;
            this.btn_DangXuat.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_DangXuat.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_DangXuat.Image = ((System.Drawing.Image)(resources.GetObject("btn_DangXuat.Image")));
            this.btn_DangXuat.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_DangXuat.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_DangXuat.Location = new System.Drawing.Point(-2, 658);
            this.btn_DangXuat.Name = "btn_DangXuat";
            this.btn_DangXuat.Size = new System.Drawing.Size(213, 41);
            this.btn_DangXuat.TabIndex = 7;
            this.btn_DangXuat.Text = "Đăng xuất";
            this.btn_DangXuat.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_DangXuat.Click += new System.EventHandler(this.btn_DangXuat_Click);
            // 
            // btn_CSCD
            // 
            this.btn_CSCD.BackColor = System.Drawing.Color.Transparent;
            this.btn_CSCD.BorderColor = System.Drawing.Color.Transparent;
            this.btn_CSCD.BorderThickness = 1;
            this.btn_CSCD.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_CSCD.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_CSCD.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_CSCD.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_CSCD.FillColor = System.Drawing.Color.Transparent;
            this.btn_CSCD.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_CSCD.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_CSCD.Image = ((System.Drawing.Image)(resources.GetObject("btn_CSCD.Image")));
            this.btn_CSCD.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_CSCD.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_CSCD.Location = new System.Drawing.Point(1, 3);
            this.btn_CSCD.Name = "btn_CSCD";
            this.btn_CSCD.Size = new System.Drawing.Size(213, 50);
            this.btn_CSCD.TabIndex = 1;
            this.btn_CSCD.Text = "Chăm sóc cư dân";
            this.btn_CSCD.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_CSCD.Click += new System.EventHandler(this.btn_CSCD_Click);
            // 
            // btn_QLTI
            // 
            this.btn_QLTI.BackColor = System.Drawing.Color.Transparent;
            this.btn_QLTI.BorderColor = System.Drawing.Color.Transparent;
            this.btn_QLTI.BorderThickness = 1;
            this.btn_QLTI.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLTI.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLTI.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_QLTI.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_QLTI.FillColor = System.Drawing.Color.Transparent;
            this.btn_QLTI.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_QLTI.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_QLTI.Image = ((System.Drawing.Image)(resources.GetObject("btn_QLTI.Image")));
            this.btn_QLTI.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLTI.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_QLTI.Location = new System.Drawing.Point(1, 53);
            this.btn_QLTI.Name = "btn_QLTI";
            this.btn_QLTI.Size = new System.Drawing.Size(213, 50);
            this.btn_QLTI.TabIndex = 2;
            this.btn_QLTI.Text = "Quản lý tiện ích";
            this.btn_QLTI.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLTI.Click += new System.EventHandler(this.btn_QLTI_Click);
            // 
            // btn_QLCP
            // 
            this.btn_QLCP.BackColor = System.Drawing.Color.Transparent;
            this.btn_QLCP.BorderColor = System.Drawing.Color.Transparent;
            this.btn_QLCP.BorderThickness = 1;
            this.btn_QLCP.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLCP.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLCP.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_QLCP.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_QLCP.FillColor = System.Drawing.Color.Transparent;
            this.btn_QLCP.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_QLCP.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_QLCP.Image = ((System.Drawing.Image)(resources.GetObject("btn_QLCP.Image")));
            this.btn_QLCP.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLCP.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_QLCP.Location = new System.Drawing.Point(1, 303);
            this.btn_QLCP.Name = "btn_QLCP";
            this.btn_QLCP.Size = new System.Drawing.Size(213, 50);
            this.btn_QLCP.TabIndex = 5;
            this.btn_QLCP.Text = "Quản lý khoản phí";
            this.btn_QLCP.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLCP.Click += new System.EventHandler(this.btn_QLCP_Click);
            // 
            // btn_QLCH
            // 
            this.btn_QLCH.BackColor = System.Drawing.Color.Transparent;
            this.btn_QLCH.BorderColor = System.Drawing.Color.Transparent;
            this.btn_QLCH.BorderThickness = 1;
            this.btn_QLCH.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLCH.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLCH.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_QLCH.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_QLCH.FillColor = System.Drawing.Color.Transparent;
            this.btn_QLCH.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_QLCH.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_QLCH.Image = ((System.Drawing.Image)(resources.GetObject("btn_QLCH.Image")));
            this.btn_QLCH.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLCH.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_QLCH.Location = new System.Drawing.Point(1, 153);
            this.btn_QLCH.Name = "btn_QLCH";
            this.btn_QLCH.Size = new System.Drawing.Size(213, 50);
            this.btn_QLCH.TabIndex = 3;
            this.btn_QLCH.Text = "Quản lý căn hộ";
            this.btn_QLCH.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLCH.Click += new System.EventHandler(this.btn_QLCH_Click);
            // 
            // btn_QLCDDD
            // 
            this.btn_QLCDDD.BackColor = System.Drawing.Color.Transparent;
            this.btn_QLCDDD.BorderColor = System.Drawing.Color.Transparent;
            this.btn_QLCDDD.BorderThickness = 1;
            this.btn_QLCDDD.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLCDDD.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLCDDD.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_QLCDDD.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_QLCDDD.FillColor = System.Drawing.Color.Transparent;
            this.btn_QLCDDD.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_QLCDDD.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_QLCDDD.Image = ((System.Drawing.Image)(resources.GetObject("btn_QLCDDD.Image")));
            this.btn_QLCDDD.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLCDDD.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_QLCDDD.Location = new System.Drawing.Point(1, 253);
            this.btn_QLCDDD.Name = "btn_QLCDDD";
            this.btn_QLCDDD.Size = new System.Drawing.Size(213, 50);
            this.btn_QLCDDD.TabIndex = 4;
            this.btn_QLCDDD.Text = "Quản lý cư dân đại diện";
            this.btn_QLCDDD.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLCDDD.Click += new System.EventHandler(this.btn_QLCDDD_Click);
            // 
            // QuanLyTaiKhoan
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.ClientSize = new System.Drawing.Size(1304, 699);
            this.Controls.Add(this.guna2GradientPanel1);
            this.Controls.Add(this.guna2GradientPanel8);
            this.Controls.Add(this.guna2GradientPanel2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.guna2GradientPanel3);
            this.Controls.Add(this.dgv_TaiKhoan);
            this.Controls.Add(this.guna2PictureBox2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "QuanLyTaiKhoan";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "QuanLyTaiKhoan";
            this.Load += new System.EventHandler(this.QuanLyTaiKhoan_Load);
            this.guna2GradientPanel2.ResumeLayout(false);
            this.guna2GradientPanel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_TaiKhoan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox2)).EndInit();
            this.guna2GradientPanel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel8;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel2;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel3;
        private Guna.UI2.WinForms.Guna2Button btn_Them;
        private Guna.UI2.WinForms.Guna2Button btn_ChinhSua;
        private System.Windows.Forms.DataGridView dgv_TaiKhoan;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox2;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel1;
        private Guna.UI2.WinForms.Guna2Button btn_TB;
        private Guna.UI2.WinForms.Guna2Button guna2Button12;
        private Guna.UI2.WinForms.Guna2Button btn_QLDV;
        private Guna.UI2.WinForms.Guna2Button btn_DangXuat;
        private Guna.UI2.WinForms.Guna2Button btn_CSCD;
        private Guna.UI2.WinForms.Guna2Button btn_QLTI;
        private Guna.UI2.WinForms.Guna2Button btn_QLCP;
        private Guna.UI2.WinForms.Guna2Button btn_QLCH;
        private Guna.UI2.WinForms.Guna2Button btn_QLCDDD;
    }
}