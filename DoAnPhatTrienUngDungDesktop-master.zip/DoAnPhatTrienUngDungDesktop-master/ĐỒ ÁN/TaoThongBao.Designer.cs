﻿namespace Đồ_án_desktop_2._0
{
    partial class TaoThongBao
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TaoThongBao));
            this.label6 = new System.Windows.Forms.Label();
            this.btn_Huy = new Guna.UI2.WinForms.Guna2Button();
            this.btn_Gui = new Guna.UI2.WinForms.Guna2Button();
            this.guna2GroupBox1 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.cbb_NguoiGui = new Guna.UI2.WinForms.Guna2ComboBox();
            this.dtp_LichGui = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.cbb_CheDo = new Guna.UI2.WinForms.Guna2ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_TieuDe = new Guna.UI2.WinForms.Guna2TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_NoiDung = new Guna.UI2.WinForms.Guna2TextBox();
            this.txt_IDThongBao = new Guna.UI2.WinForms.Guna2TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.guna2GroupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.DimGray;
            this.label6.Location = new System.Drawing.Point(298, 22);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(224, 24);
            this.label6.TabIndex = 56;
            this.label6.Text = "CHI TIẾT THÔNG BÁO";
            // 
            // btn_Huy
            // 
            this.btn_Huy.BorderRadius = 10;
            this.btn_Huy.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_Huy.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_Huy.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_Huy.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_Huy.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Huy.ForeColor = System.Drawing.Color.White;
            this.btn_Huy.Location = new System.Drawing.Point(420, 318);
            this.btn_Huy.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Huy.Name = "btn_Huy";
            this.btn_Huy.Size = new System.Drawing.Size(148, 38);
            this.btn_Huy.TabIndex = 55;
            this.btn_Huy.Text = "Hủy";
            this.btn_Huy.Click += new System.EventHandler(this.btn_Huyr_Click);
            // 
            // btn_Gui
            // 
            this.btn_Gui.BorderRadius = 10;
            this.btn_Gui.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_Gui.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_Gui.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_Gui.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_Gui.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Gui.ForeColor = System.Drawing.Color.White;
            this.btn_Gui.Location = new System.Drawing.Point(247, 318);
            this.btn_Gui.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Gui.Name = "btn_Gui";
            this.btn_Gui.Size = new System.Drawing.Size(148, 38);
            this.btn_Gui.TabIndex = 54;
            this.btn_Gui.Text = "Gửi";
            this.btn_Gui.Click += new System.EventHandler(this.btnguithong_Click);
            // 
            // guna2GroupBox1
            // 
            this.guna2GroupBox1.BackColor = System.Drawing.Color.Transparent;
            this.guna2GroupBox1.BorderRadius = 10;
            this.guna2GroupBox1.CausesValidation = false;
            this.guna2GroupBox1.Controls.Add(this.cbb_NguoiGui);
            this.guna2GroupBox1.Controls.Add(this.dtp_LichGui);
            this.guna2GroupBox1.Controls.Add(this.label9);
            this.guna2GroupBox1.Controls.Add(this.guna2Panel1);
            this.guna2GroupBox1.Controls.Add(this.cbb_CheDo);
            this.guna2GroupBox1.Controls.Add(this.label7);
            this.guna2GroupBox1.Controls.Add(this.txt_TieuDe);
            this.guna2GroupBox1.Controls.Add(this.label5);
            this.guna2GroupBox1.Controls.Add(this.label3);
            this.guna2GroupBox1.Controls.Add(this.txt_NoiDung);
            this.guna2GroupBox1.Controls.Add(this.txt_IDThongBao);
            this.guna2GroupBox1.Controls.Add(this.label1);
            this.guna2GroupBox1.Controls.Add(this.label2);
            this.guna2GroupBox1.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.guna2GroupBox1.FillColor = System.Drawing.Color.Transparent;
            this.guna2GroupBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GroupBox1.ForeColor = System.Drawing.Color.Transparent;
            this.guna2GroupBox1.Location = new System.Drawing.Point(34, 54);
            this.guna2GroupBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2GroupBox1.Name = "guna2GroupBox1";
            this.guna2GroupBox1.Size = new System.Drawing.Size(743, 242);
            this.guna2GroupBox1.TabIndex = 57;
            this.guna2GroupBox1.Text = "guna2GroupBox1";
            // 
            // cbb_NguoiGui
            // 
            this.cbb_NguoiGui.BackColor = System.Drawing.Color.Transparent;
            this.cbb_NguoiGui.BorderRadius = 10;
            this.cbb_NguoiGui.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cbb_NguoiGui.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbb_NguoiGui.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbb_NguoiGui.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbb_NguoiGui.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbb_NguoiGui.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cbb_NguoiGui.ItemHeight = 30;
            this.cbb_NguoiGui.Location = new System.Drawing.Point(117, 67);
            this.cbb_NguoiGui.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbb_NguoiGui.Name = "cbb_NguoiGui";
            this.cbb_NguoiGui.Size = new System.Drawing.Size(255, 36);
            this.cbb_NguoiGui.TabIndex = 64;
            // 
            // dtp_LichGui
            // 
            this.dtp_LichGui.Animated = true;
            this.dtp_LichGui.AutoRoundedCorners = true;
            this.dtp_LichGui.BackColor = System.Drawing.Color.Transparent;
            this.dtp_LichGui.BorderColor = System.Drawing.Color.Transparent;
            this.dtp_LichGui.BorderRadius = 13;
            this.dtp_LichGui.Checked = true;
            this.dtp_LichGui.FillColor = System.Drawing.Color.White;
            this.dtp_LichGui.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.dtp_LichGui.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dtp_LichGui.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.dtp_LichGui.Location = new System.Drawing.Point(116, 194);
            this.dtp_LichGui.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtp_LichGui.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtp_LichGui.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtp_LichGui.Name = "dtp_LichGui";
            this.dtp_LichGui.Size = new System.Drawing.Size(244, 29);
            this.dtp_LichGui.TabIndex = 58;
            this.dtp_LichGui.Value = new System.DateTime(2024, 12, 8, 16, 6, 23, 817);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(44, 199);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(64, 20);
            this.label9.TabIndex = 61;
            this.label9.Text = "Lịch gửi:";
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.guna2Panel1.Location = new System.Drawing.Point(9, 169);
            this.guna2Panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.Size = new System.Drawing.Size(725, 4);
            this.guna2Panel1.TabIndex = 60;
            // 
            // cbb_CheDo
            // 
            this.cbb_CheDo.BackColor = System.Drawing.Color.Transparent;
            this.cbb_CheDo.BorderRadius = 10;
            this.cbb_CheDo.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cbb_CheDo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbb_CheDo.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbb_CheDo.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbb_CheDo.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbb_CheDo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cbb_CheDo.ItemHeight = 30;
            this.cbb_CheDo.Location = new System.Drawing.Point(469, 69);
            this.cbb_CheDo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbb_CheDo.Name = "cbb_CheDo";
            this.cbb_CheDo.Size = new System.Drawing.Size(255, 36);
            this.cbb_CheDo.TabIndex = 59;
            this.cbb_CheDo.SelectedIndexChanged += new System.EventHandler(this.cbbchedogui_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(49, 126);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(61, 20);
            this.label7.TabIndex = 42;
            this.label7.Text = "Tiêu đề:";
            // 
            // txt_TieuDe
            // 
            this.txt_TieuDe.BorderRadius = 10;
            this.txt_TieuDe.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_TieuDe.DefaultText = "";
            this.txt_TieuDe.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_TieuDe.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_TieuDe.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_TieuDe.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_TieuDe.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_TieuDe.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txt_TieuDe.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_TieuDe.Location = new System.Drawing.Point(116, 118);
            this.txt_TieuDe.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_TieuDe.Name = "txt_TieuDe";
            this.txt_TieuDe.PasswordChar = '\0';
            this.txt_TieuDe.PlaceholderText = "";
            this.txt_TieuDe.SelectedText = "";
            this.txt_TieuDe.Size = new System.Drawing.Size(255, 36);
            this.txt_TieuDe.TabIndex = 43;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(378, 75);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 20);
            this.label5.TabIndex = 36;
            this.label5.Text = "Chế độ gửi:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(388, 23);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 20);
            this.label3.TabIndex = 34;
            this.label3.Text = "Nội dung:";
            // 
            // txt_NoiDung
            // 
            this.txt_NoiDung.BorderRadius = 10;
            this.txt_NoiDung.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_NoiDung.DefaultText = "";
            this.txt_NoiDung.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_NoiDung.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_NoiDung.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_NoiDung.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_NoiDung.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_NoiDung.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txt_NoiDung.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_NoiDung.Location = new System.Drawing.Point(469, 15);
            this.txt_NoiDung.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_NoiDung.Name = "txt_NoiDung";
            this.txt_NoiDung.PasswordChar = '\0';
            this.txt_NoiDung.PlaceholderText = "";
            this.txt_NoiDung.SelectedText = "";
            this.txt_NoiDung.Size = new System.Drawing.Size(255, 36);
            this.txt_NoiDung.TabIndex = 39;
            // 
            // txt_IDThongBao
            // 
            this.txt_IDThongBao.BorderRadius = 10;
            this.txt_IDThongBao.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_IDThongBao.DefaultText = "";
            this.txt_IDThongBao.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_IDThongBao.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_IDThongBao.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_IDThongBao.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_IDThongBao.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_IDThongBao.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txt_IDThongBao.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_IDThongBao.Location = new System.Drawing.Point(116, 15);
            this.txt_IDThongBao.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_IDThongBao.Name = "txt_IDThongBao";
            this.txt_IDThongBao.PasswordChar = '\0';
            this.txt_IDThongBao.PlaceholderText = "";
            this.txt_IDThongBao.SelectedText = "";
            this.txt_IDThongBao.Size = new System.Drawing.Size(255, 36);
            this.txt_IDThongBao.TabIndex = 37;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(5, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 20);
            this.label1.TabIndex = 32;
            this.label1.Text = "ID thông báo:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(24, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 20);
            this.label2.TabIndex = 33;
            this.label2.Text = "Người gửi:";
            // 
            // TaoThongBao
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(820, 365);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.btn_Huy);
            this.Controls.Add(this.btn_Gui);
            this.Controls.Add(this.guna2GroupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "TaoThongBao";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TaoThongBao";
            this.Load += new System.EventHandler(this.TaoThongBao_Load);
            this.guna2GroupBox1.ResumeLayout(false);
            this.guna2GroupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label6;
        private Guna.UI2.WinForms.Guna2Button btn_Huy;
        private Guna.UI2.WinForms.Guna2Button btn_Gui;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox1;
        private System.Windows.Forms.Label label7;
        private Guna.UI2.WinForms.Guna2TextBox txt_TieuDe;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2TextBox txt_NoiDung;
        private Guna.UI2.WinForms.Guna2TextBox txt_IDThongBao;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2DateTimePicker dtp_LichGui;
        private Guna.UI2.WinForms.Guna2ComboBox cbb_CheDo;
        private System.Windows.Forms.Label label9;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Guna.UI2.WinForms.Guna2ComboBox cbb_NguoiGui;
    }
}