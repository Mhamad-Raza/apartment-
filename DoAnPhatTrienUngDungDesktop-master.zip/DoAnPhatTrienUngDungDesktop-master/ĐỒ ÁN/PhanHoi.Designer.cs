﻿namespace Đồ_án_desktop_2._0
{
    partial class PhanHoi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_IDPhanHoi = new Guna.UI2.WinForms.Guna2TextBox();
            this.txt_IDKhieuNai = new Guna.UI2.WinForms.Guna2TextBox();
            this.txt_NoiDungPhanHoi = new Guna.UI2.WinForms.Guna2TextBox();
            this.btn_PhanHoi = new Guna.UI2.WinForms.Guna2Button();
            this.btn_Huy = new Guna.UI2.WinForms.Guna2Button();
            this.label6 = new System.Windows.Forms.Label();
            this.guna2GroupBox1 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.dtp_NgayGui = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.guna2GroupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(68, 86);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID Phản Hồi:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(66, 150);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(95, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "ID Khiếu Nại:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(88, 214);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Nội dung:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(90, 314);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Ngày gửi:";
            // 
            // txt_IDPhanHoi
            // 
            this.txt_IDPhanHoi.BorderRadius = 10;
            this.txt_IDPhanHoi.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_IDPhanHoi.DefaultText = "";
            this.txt_IDPhanHoi.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_IDPhanHoi.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_IDPhanHoi.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_IDPhanHoi.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_IDPhanHoi.Enabled = false;
            this.txt_IDPhanHoi.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_IDPhanHoi.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txt_IDPhanHoi.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_IDPhanHoi.Location = new System.Drawing.Point(186, 83);
            this.txt_IDPhanHoi.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_IDPhanHoi.Name = "txt_IDPhanHoi";
            this.txt_IDPhanHoi.PasswordChar = '\0';
            this.txt_IDPhanHoi.PlaceholderText = "";
            this.txt_IDPhanHoi.SelectedText = "";
            this.txt_IDPhanHoi.Size = new System.Drawing.Size(457, 39);
            this.txt_IDPhanHoi.TabIndex = 23;
            // 
            // txt_IDKhieuNai
            // 
            this.txt_IDKhieuNai.BorderRadius = 10;
            this.txt_IDKhieuNai.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_IDKhieuNai.DefaultText = "";
            this.txt_IDKhieuNai.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_IDKhieuNai.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_IDKhieuNai.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_IDKhieuNai.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_IDKhieuNai.Enabled = false;
            this.txt_IDKhieuNai.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_IDKhieuNai.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txt_IDKhieuNai.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_IDKhieuNai.Location = new System.Drawing.Point(186, 147);
            this.txt_IDKhieuNai.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_IDKhieuNai.Name = "txt_IDKhieuNai";
            this.txt_IDKhieuNai.PasswordChar = '\0';
            this.txt_IDKhieuNai.PlaceholderText = "";
            this.txt_IDKhieuNai.SelectedText = "";
            this.txt_IDKhieuNai.Size = new System.Drawing.Size(457, 39);
            this.txt_IDKhieuNai.TabIndex = 24;
            // 
            // txt_NoiDungPhanHoi
            // 
            this.txt_NoiDungPhanHoi.BorderRadius = 10;
            this.txt_NoiDungPhanHoi.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_NoiDungPhanHoi.DefaultText = "";
            this.txt_NoiDungPhanHoi.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_NoiDungPhanHoi.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_NoiDungPhanHoi.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_NoiDungPhanHoi.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_NoiDungPhanHoi.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_NoiDungPhanHoi.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txt_NoiDungPhanHoi.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_NoiDungPhanHoi.Location = new System.Drawing.Point(186, 211);
            this.txt_NoiDungPhanHoi.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_NoiDungPhanHoi.Name = "txt_NoiDungPhanHoi";
            this.txt_NoiDungPhanHoi.PasswordChar = '\0';
            this.txt_NoiDungPhanHoi.PlaceholderText = "";
            this.txt_NoiDungPhanHoi.SelectedText = "";
            this.txt_NoiDungPhanHoi.Size = new System.Drawing.Size(457, 80);
            this.txt_NoiDungPhanHoi.TabIndex = 25;
            // 
            // btn_PhanHoi
            // 
            this.btn_PhanHoi.BorderRadius = 10;
            this.btn_PhanHoi.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_PhanHoi.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_PhanHoi.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_PhanHoi.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_PhanHoi.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_PhanHoi.ForeColor = System.Drawing.Color.White;
            this.btn_PhanHoi.Location = new System.Drawing.Point(186, 376);
            this.btn_PhanHoi.Name = "btn_PhanHoi";
            this.btn_PhanHoi.Size = new System.Drawing.Size(167, 47);
            this.btn_PhanHoi.TabIndex = 28;
            this.btn_PhanHoi.Text = "Phản hồi";
            this.btn_PhanHoi.Click += new System.EventHandler(this.btnPhanHoi_Click_1);
            // 
            // btn_Huy
            // 
            this.btn_Huy.BorderRadius = 10;
            this.btn_Huy.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_Huy.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_Huy.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_Huy.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_Huy.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Huy.ForeColor = System.Drawing.Color.White;
            this.btn_Huy.Location = new System.Drawing.Point(370, 376);
            this.btn_Huy.Name = "btn_Huy";
            this.btn_Huy.Size = new System.Drawing.Size(167, 47);
            this.btn_Huy.TabIndex = 29;
            this.btn_Huy.Text = "Hủy";
            this.btn_Huy.Click += new System.EventHandler(this.btnHuyPhanHoi_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.DimGray;
            this.label6.Location = new System.Drawing.Point(248, 26);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(200, 24);
            this.label6.TabIndex = 30;
            this.label6.Text = "CHI TIẾT PHẢN HỒI";
            // 
            // guna2GroupBox1
            // 
            this.guna2GroupBox1.BackColor = System.Drawing.Color.Transparent;
            this.guna2GroupBox1.BorderRadius = 10;
            this.guna2GroupBox1.CausesValidation = false;
            this.guna2GroupBox1.Controls.Add(this.dtp_NgayGui);
            this.guna2GroupBox1.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.guna2GroupBox1.FillColor = System.Drawing.Color.Transparent;
            this.guna2GroupBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GroupBox1.ForeColor = System.Drawing.Color.Transparent;
            this.guna2GroupBox1.Location = new System.Drawing.Point(51, 67);
            this.guna2GroupBox1.Name = "guna2GroupBox1";
            this.guna2GroupBox1.Size = new System.Drawing.Size(624, 293);
            this.guna2GroupBox1.TabIndex = 31;
            this.guna2GroupBox1.Text = "guna2GroupBox1";
            // 
            // dtp_NgayGui
            // 
            this.dtp_NgayGui.BackColor = System.Drawing.SystemColors.Control;
            this.dtp_NgayGui.BorderRadius = 10;
            this.dtp_NgayGui.Checked = true;
            this.dtp_NgayGui.Enabled = false;
            this.dtp_NgayGui.FillColor = System.Drawing.SystemColors.Control;
            this.dtp_NgayGui.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.dtp_NgayGui.ForeColor = System.Drawing.Color.Black;
            this.dtp_NgayGui.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.dtp_NgayGui.Location = new System.Drawing.Point(138, 244);
            this.dtp_NgayGui.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtp_NgayGui.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtp_NgayGui.Name = "dtp_NgayGui";
            this.dtp_NgayGui.Size = new System.Drawing.Size(454, 36);
            this.dtp_NgayGui.TabIndex = 32;
            this.dtp_NgayGui.Value = new System.DateTime(2024, 12, 20, 0, 0, 0, 0);
            this.dtp_NgayGui.ValueChanged += new System.EventHandler(this.dtp_NgayGui_ValueChanged);
            // 
            // PhanHoi
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.ClientSize = new System.Drawing.Size(733, 435);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.btn_Huy);
            this.Controls.Add(this.btn_PhanHoi);
            this.Controls.Add(this.txt_NoiDungPhanHoi);
            this.Controls.Add(this.txt_IDKhieuNai);
            this.Controls.Add(this.txt_IDPhanHoi);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.guna2GroupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "PhanHoi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Phản hồi";
            this.guna2GroupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private Guna.UI2.WinForms.Guna2TextBox txt_IDPhanHoi;
        private Guna.UI2.WinForms.Guna2TextBox txt_IDKhieuNai;
        private Guna.UI2.WinForms.Guna2TextBox txt_NoiDungPhanHoi;
        private Guna.UI2.WinForms.Guna2Button btn_PhanHoi;
        private Guna.UI2.WinForms.Guna2Button btn_Huy;
        private System.Windows.Forms.Label label6;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox1;
        private Guna.UI2.WinForms.Guna2DateTimePicker dtp_NgayGui;
    }
}