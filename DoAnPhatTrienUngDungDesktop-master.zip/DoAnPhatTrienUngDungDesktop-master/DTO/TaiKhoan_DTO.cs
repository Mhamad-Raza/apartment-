﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class TaiKhoan_DTO
    {
        public string ID_TaiKhoan { get; set; }
        public string ID_CanHo { get; set; }
        public string TenDangNhap { get; set; }
        public string MatKhau { get; set; }
    }
}
