﻿namespace Đồ_án_desktop_2._0
{
    partial class ManHinhChinh
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ManHinhChinh));
            this.guna2GradientPanel2 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.guna2GradientPanel6 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_QLCDDD = new Guna.UI2.WinForms.Guna2Button();
            this.btn_QLCH = new Guna.UI2.WinForms.Guna2Button();
            this.btn_QLCP = new Guna.UI2.WinForms.Guna2Button();
            this.btn_QLTI = new Guna.UI2.WinForms.Guna2Button();
            this.btn_CSCD = new Guna.UI2.WinForms.Guna2Button();
            this.btn_DangXuat = new Guna.UI2.WinForms.Guna2Button();
            this.btn_QLDV = new Guna.UI2.WinForms.Guna2Button();
            this.btn_QLTK = new Guna.UI2.WinForms.Guna2Button();
            this.btn_TB = new Guna.UI2.WinForms.Guna2Button();
            this.guna2GradientPanel1 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2GradientPanel2.SuspendLayout();
            this.guna2GradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2GradientPanel2
            // 
            this.guna2GradientPanel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientPanel2.Controls.Add(this.guna2GradientPanel6);
            this.guna2GradientPanel2.FillColor = System.Drawing.Color.White;
            this.guna2GradientPanel2.FillColor2 = System.Drawing.Color.LightGray;
            this.guna2GradientPanel2.Location = new System.Drawing.Point(209, 1);
            this.guna2GradientPanel2.Name = "guna2GradientPanel2";
            this.guna2GradientPanel2.Size = new System.Drawing.Size(10, 700);
            this.guna2GradientPanel2.TabIndex = 84;
            // 
            // guna2GradientPanel6
            // 
            this.guna2GradientPanel6.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientPanel6.FillColor = System.Drawing.Color.Gainsboro;
            this.guna2GradientPanel6.FillColor2 = System.Drawing.Color.WhiteSmoke;
            this.guna2GradientPanel6.Location = new System.Drawing.Point(9, 232);
            this.guna2GradientPanel6.Name = "guna2GradientPanel6";
            this.guna2GradientPanel6.Size = new System.Drawing.Size(1089, 5);
            this.guna2GradientPanel6.TabIndex = 52;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Segoe UI Black", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gray;
            this.label1.Location = new System.Drawing.Point(330, 526);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(812, 65);
            this.label1.TabIndex = 83;
            this.label1.Text = "PHẦN MỀM QUẢN LÝ CHUNG CƯ";
            // 
            // btn_QLCDDD
            // 
            this.btn_QLCDDD.BackColor = System.Drawing.Color.Transparent;
            this.btn_QLCDDD.BorderColor = System.Drawing.Color.Transparent;
            this.btn_QLCDDD.BorderThickness = 1;
            this.btn_QLCDDD.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLCDDD.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLCDDD.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_QLCDDD.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_QLCDDD.FillColor = System.Drawing.Color.Transparent;
            this.btn_QLCDDD.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_QLCDDD.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_QLCDDD.Image = ((System.Drawing.Image)(resources.GetObject("btn_QLCDDD.Image")));
            this.btn_QLCDDD.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLCDDD.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_QLCDDD.Location = new System.Drawing.Point(-3, 253);
            this.btn_QLCDDD.Name = "btn_QLCDDD";
            this.btn_QLCDDD.Size = new System.Drawing.Size(220, 50);
            this.btn_QLCDDD.TabIndex = 4;
            this.btn_QLCDDD.Text = "Quản lý cư dân đại diện";
            this.btn_QLCDDD.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLCDDD.Click += new System.EventHandler(this.btn_QLCDDD_Click);
            // 
            // btn_QLCH
            // 
            this.btn_QLCH.BackColor = System.Drawing.Color.Transparent;
            this.btn_QLCH.BorderColor = System.Drawing.Color.Transparent;
            this.btn_QLCH.BorderThickness = 1;
            this.btn_QLCH.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLCH.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLCH.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_QLCH.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_QLCH.FillColor = System.Drawing.Color.Transparent;
            this.btn_QLCH.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_QLCH.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_QLCH.Image = ((System.Drawing.Image)(resources.GetObject("btn_QLCH.Image")));
            this.btn_QLCH.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLCH.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_QLCH.Location = new System.Drawing.Point(2, 153);
            this.btn_QLCH.Name = "btn_QLCH";
            this.btn_QLCH.Size = new System.Drawing.Size(213, 50);
            this.btn_QLCH.TabIndex = 3;
            this.btn_QLCH.Text = "Quản lý căn hộ";
            this.btn_QLCH.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLCH.Click += new System.EventHandler(this.btn_QLCH_Click);
            // 
            // btn_QLCP
            // 
            this.btn_QLCP.BackColor = System.Drawing.Color.Transparent;
            this.btn_QLCP.BorderColor = System.Drawing.Color.Transparent;
            this.btn_QLCP.BorderThickness = 1;
            this.btn_QLCP.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLCP.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLCP.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_QLCP.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_QLCP.FillColor = System.Drawing.Color.Transparent;
            this.btn_QLCP.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_QLCP.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_QLCP.Image = ((System.Drawing.Image)(resources.GetObject("btn_QLCP.Image")));
            this.btn_QLCP.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLCP.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_QLCP.Location = new System.Drawing.Point(2, 303);
            this.btn_QLCP.Name = "btn_QLCP";
            this.btn_QLCP.Size = new System.Drawing.Size(213, 50);
            this.btn_QLCP.TabIndex = 5;
            this.btn_QLCP.Text = "Quản lý khoản phí";
            this.btn_QLCP.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLCP.Click += new System.EventHandler(this.btn_QLCP_Click);
            // 
            // btn_QLTI
            // 
            this.btn_QLTI.BackColor = System.Drawing.Color.Transparent;
            this.btn_QLTI.BorderColor = System.Drawing.Color.Transparent;
            this.btn_QLTI.BorderThickness = 1;
            this.btn_QLTI.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLTI.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLTI.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_QLTI.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_QLTI.FillColor = System.Drawing.Color.Transparent;
            this.btn_QLTI.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_QLTI.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_QLTI.Image = ((System.Drawing.Image)(resources.GetObject("btn_QLTI.Image")));
            this.btn_QLTI.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLTI.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_QLTI.Location = new System.Drawing.Point(2, 53);
            this.btn_QLTI.Name = "btn_QLTI";
            this.btn_QLTI.Size = new System.Drawing.Size(213, 50);
            this.btn_QLTI.TabIndex = 2;
            this.btn_QLTI.Text = "Quản lý tiện ích";
            this.btn_QLTI.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLTI.Click += new System.EventHandler(this.btn_QLTI_Click);
            // 
            // btn_CSCD
            // 
            this.btn_CSCD.BackColor = System.Drawing.Color.Transparent;
            this.btn_CSCD.BorderColor = System.Drawing.Color.Transparent;
            this.btn_CSCD.BorderThickness = 1;
            this.btn_CSCD.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_CSCD.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_CSCD.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_CSCD.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_CSCD.FillColor = System.Drawing.Color.Transparent;
            this.btn_CSCD.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_CSCD.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_CSCD.Image = ((System.Drawing.Image)(resources.GetObject("btn_CSCD.Image")));
            this.btn_CSCD.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_CSCD.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_CSCD.Location = new System.Drawing.Point(2, 3);
            this.btn_CSCD.Name = "btn_CSCD";
            this.btn_CSCD.Size = new System.Drawing.Size(213, 50);
            this.btn_CSCD.TabIndex = 1;
            this.btn_CSCD.Text = "Chăm sóc cư dân";
            this.btn_CSCD.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_CSCD.Click += new System.EventHandler(this.btn_CSCD_Click);
            // 
            // btn_DangXuat
            // 
            this.btn_DangXuat.BackColor = System.Drawing.Color.Transparent;
            this.btn_DangXuat.BorderColor = System.Drawing.Color.Transparent;
            this.btn_DangXuat.BorderThickness = 2;
            this.btn_DangXuat.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_DangXuat.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_DangXuat.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_DangXuat.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_DangXuat.FillColor = System.Drawing.Color.Transparent;
            this.btn_DangXuat.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_DangXuat.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_DangXuat.Image = ((System.Drawing.Image)(resources.GetObject("btn_DangXuat.Image")));
            this.btn_DangXuat.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_DangXuat.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_DangXuat.Location = new System.Drawing.Point(2, 655);
            this.btn_DangXuat.Name = "btn_DangXuat";
            this.btn_DangXuat.Size = new System.Drawing.Size(213, 41);
            this.btn_DangXuat.TabIndex = 7;
            this.btn_DangXuat.Text = "Đăng xuất";
            this.btn_DangXuat.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_DangXuat.Click += new System.EventHandler(this.btn_DangXuat_Click);
            // 
            // btn_QLDV
            // 
            this.btn_QLDV.BackColor = System.Drawing.Color.Transparent;
            this.btn_QLDV.BorderColor = System.Drawing.Color.Transparent;
            this.btn_QLDV.BorderThickness = 1;
            this.btn_QLDV.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLDV.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLDV.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_QLDV.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_QLDV.FillColor = System.Drawing.Color.Transparent;
            this.btn_QLDV.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_QLDV.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_QLDV.Image = ((System.Drawing.Image)(resources.GetObject("btn_QLDV.Image")));
            this.btn_QLDV.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLDV.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_QLDV.Location = new System.Drawing.Point(2, 103);
            this.btn_QLDV.Name = "btn_QLDV";
            this.btn_QLDV.Size = new System.Drawing.Size(213, 50);
            this.btn_QLDV.TabIndex = 8;
            this.btn_QLDV.Text = "Quản lý dịch vụ";
            this.btn_QLDV.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLDV.Click += new System.EventHandler(this.btn_QLDV_Click);
            // 
            // btn_QLTK
            // 
            this.btn_QLTK.BackColor = System.Drawing.Color.Transparent;
            this.btn_QLTK.BorderColor = System.Drawing.Color.Transparent;
            this.btn_QLTK.BorderThickness = 1;
            this.btn_QLTK.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLTK.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLTK.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_QLTK.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_QLTK.FillColor = System.Drawing.Color.Transparent;
            this.btn_QLTK.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_QLTK.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_QLTK.Image = ((System.Drawing.Image)(resources.GetObject("btn_QLTK.Image")));
            this.btn_QLTK.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLTK.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_QLTK.Location = new System.Drawing.Point(2, 203);
            this.btn_QLTK.Name = "btn_QLTK";
            this.btn_QLTK.Size = new System.Drawing.Size(213, 50);
            this.btn_QLTK.TabIndex = 9;
            this.btn_QLTK.Text = "Quản lý tài khoản";
            this.btn_QLTK.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLTK.Click += new System.EventHandler(this.btn_QLTK_Click);
            // 
            // btn_TB
            // 
            this.btn_TB.BackColor = System.Drawing.Color.White;
            this.btn_TB.BorderColor = System.Drawing.Color.Transparent;
            this.btn_TB.BorderThickness = 1;
            this.btn_TB.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_TB.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_TB.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_TB.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_TB.FillColor = System.Drawing.Color.Transparent;
            this.btn_TB.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_TB.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_TB.Image = ((System.Drawing.Image)(resources.GetObject("btn_TB.Image")));
            this.btn_TB.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_TB.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_TB.Location = new System.Drawing.Point(2, 353);
            this.btn_TB.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_TB.Name = "btn_TB";
            this.btn_TB.Size = new System.Drawing.Size(213, 50);
            this.btn_TB.TabIndex = 87;
            this.btn_TB.Text = "Thông báo";
            this.btn_TB.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_TB.Click += new System.EventHandler(this.btn_TB_Click);
            // 
            // guna2GradientPanel1
            // 
            this.guna2GradientPanel1.BackColor = System.Drawing.Color.White;
            this.guna2GradientPanel1.Controls.Add(this.btn_TB);
            this.guna2GradientPanel1.Controls.Add(this.btn_QLTK);
            this.guna2GradientPanel1.Controls.Add(this.btn_QLDV);
            this.guna2GradientPanel1.Controls.Add(this.btn_DangXuat);
            this.guna2GradientPanel1.Controls.Add(this.btn_CSCD);
            this.guna2GradientPanel1.Controls.Add(this.btn_QLTI);
            this.guna2GradientPanel1.Controls.Add(this.btn_QLCP);
            this.guna2GradientPanel1.Controls.Add(this.btn_QLCH);
            this.guna2GradientPanel1.Controls.Add(this.btn_QLCDDD);
            this.guna2GradientPanel1.Location = new System.Drawing.Point(-2, -1);
            this.guna2GradientPanel1.Name = "guna2GradientPanel1";
            this.guna2GradientPanel1.Size = new System.Drawing.Size(211, 701);
            this.guna2GradientPanel1.TabIndex = 86;
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox1.Image = global::ĐỒ_ÁN.Properties.Resources.logo;
            this.guna2PictureBox1.ImageRotate = 0F;
            this.guna2PictureBox1.Location = new System.Drawing.Point(569, 132);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.Size = new System.Drawing.Size(352, 350);
            this.guna2PictureBox1.TabIndex = 87;
            this.guna2PictureBox1.TabStop = false;
            // 
            // ManHinhChinh
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1304, 699);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.guna2PictureBox1);
            this.Controls.Add(this.guna2GradientPanel2);
            this.Controls.Add(this.guna2GradientPanel1);
            this.DoubleBuffered = true;
            this.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ManHinhChinh";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ManHinhChinh";
            this.Load += new System.EventHandler(this.ManHinhChinh_Load);
            this.guna2GradientPanel2.ResumeLayout(false);
            this.guna2GradientPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel2;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel6;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2Button btn_QLCDDD;
        private Guna.UI2.WinForms.Guna2Button btn_QLCH;
        private Guna.UI2.WinForms.Guna2Button btn_QLCP;
        private Guna.UI2.WinForms.Guna2Button btn_QLTI;
        private Guna.UI2.WinForms.Guna2Button btn_CSCD;
        private Guna.UI2.WinForms.Guna2Button btn_DangXuat;
        private Guna.UI2.WinForms.Guna2Button btn_QLDV;
        private Guna.UI2.WinForms.Guna2Button btn_QLTK;
        private Guna.UI2.WinForms.Guna2Button btn_TB;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel1;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
    }
}