﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class CanHo_DTO
    {
        public string ID_CanHo { get; set; }
        public string SoCanHo { get; set; }
        public string Tang { get; set; }
        public string LoaiCanHo { get; set; }
        public string DienTich { get; set; }
        public string Gia { get; set; }
        public string TinhTrang { get; set; }
    }
}
