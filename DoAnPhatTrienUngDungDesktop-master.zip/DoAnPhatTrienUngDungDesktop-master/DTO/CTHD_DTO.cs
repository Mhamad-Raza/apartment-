﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class CTHD_DTO
    {
        public string ID_ChiTietHoaDon { get; set; }
        public string ID_HoaDon { get; set; }
        public string ID_CanHo { get; set; }
        public string TenHoaDon { get; set; }
        public string TrangThai { get; set; }
        public string NgayLapHoaDon { get; set; }
        public string SoLuong { get; set; }
        public string TenKhoanPhi { get; set; }
        
        public string ID_Thongke { get; set; }
        public string DonGia { get; set; }
    }
}
