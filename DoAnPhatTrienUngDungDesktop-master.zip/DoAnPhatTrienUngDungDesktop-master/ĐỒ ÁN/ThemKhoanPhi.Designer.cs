﻿namespace Đồ_án_desktop_2._0
{
    partial class ThemKhoanPhi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ThemKhoanPhi));
            this.label6 = new System.Windows.Forms.Label();
            this.btn_Huy = new Guna.UI2.WinForms.Guna2Button();
            this.btn_Them = new Guna.UI2.WinForms.Guna2Button();
            this.guna2GroupBox1 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.cbb_TrangThai = new Guna.UI2.WinForms.Guna2ComboBox();
            this.cbb_ChuKy = new Guna.UI2.WinForms.Guna2ComboBox();
            this.lbldongia = new System.Windows.Forms.Label();
            this.txt_DonGia = new Guna.UI2.WinForms.Guna2TextBox();
            this.lblchuky = new System.Windows.Forms.Label();
            this.lbltrangthai = new System.Windows.Forms.Label();
            this.txt_ID = new Guna.UI2.WinForms.Guna2TextBox();
            this.lblidkhoanphi = new System.Windows.Forms.Label();
            this.lbltenkhoanphi = new System.Windows.Forms.Label();
            this.txt_Ten = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2GroupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.DimGray;
            this.label6.Location = new System.Drawing.Point(314, 14);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(174, 24);
            this.label6.TabIndex = 56;
            this.label6.Text = "CHI TIẾT CHI PHÍ";
            // 
            // btn_Huy
            // 
            this.btn_Huy.BorderRadius = 10;
            this.btn_Huy.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_Huy.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_Huy.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_Huy.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_Huy.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Huy.ForeColor = System.Drawing.Color.White;
            this.btn_Huy.Location = new System.Drawing.Point(416, 228);
            this.btn_Huy.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Huy.Name = "btn_Huy";
            this.btn_Huy.Size = new System.Drawing.Size(148, 38);
            this.btn_Huy.TabIndex = 55;
            this.btn_Huy.Text = "Hủy";
            this.btn_Huy.Click += new System.EventHandler(this.btn_Huy_Click);
            // 
            // btn_Them
            // 
            this.btn_Them.BorderRadius = 10;
            this.btn_Them.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_Them.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_Them.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_Them.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_Them.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Them.ForeColor = System.Drawing.Color.White;
            this.btn_Them.Location = new System.Drawing.Point(252, 228);
            this.btn_Them.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Them.Name = "btn_Them";
            this.btn_Them.Size = new System.Drawing.Size(148, 38);
            this.btn_Them.TabIndex = 54;
            this.btn_Them.Text = "Thêm";
            this.btn_Them.Click += new System.EventHandler(this.btn_Them_Click);
            // 
            // guna2GroupBox1
            // 
            this.guna2GroupBox1.BackColor = System.Drawing.Color.Transparent;
            this.guna2GroupBox1.BorderRadius = 10;
            this.guna2GroupBox1.CausesValidation = false;
            this.guna2GroupBox1.Controls.Add(this.cbb_TrangThai);
            this.guna2GroupBox1.Controls.Add(this.cbb_ChuKy);
            this.guna2GroupBox1.Controls.Add(this.lbldongia);
            this.guna2GroupBox1.Controls.Add(this.txt_DonGia);
            this.guna2GroupBox1.Controls.Add(this.lblchuky);
            this.guna2GroupBox1.Controls.Add(this.lbltrangthai);
            this.guna2GroupBox1.Controls.Add(this.txt_ID);
            this.guna2GroupBox1.Controls.Add(this.lblidkhoanphi);
            this.guna2GroupBox1.Controls.Add(this.lbltenkhoanphi);
            this.guna2GroupBox1.Controls.Add(this.txt_Ten);
            this.guna2GroupBox1.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.guna2GroupBox1.FillColor = System.Drawing.Color.Transparent;
            this.guna2GroupBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GroupBox1.ForeColor = System.Drawing.Color.Transparent;
            this.guna2GroupBox1.Location = new System.Drawing.Point(15, 46);
            this.guna2GroupBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2GroupBox1.Name = "guna2GroupBox1";
            this.guna2GroupBox1.Size = new System.Drawing.Size(788, 177);
            this.guna2GroupBox1.TabIndex = 57;
            this.guna2GroupBox1.Text = "guna2GroupBox1";
            // 
            // cbb_TrangThai
            // 
            this.cbb_TrangThai.BackColor = System.Drawing.Color.Transparent;
            this.cbb_TrangThai.BorderRadius = 10;
            this.cbb_TrangThai.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cbb_TrangThai.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbb_TrangThai.Enabled = false;
            this.cbb_TrangThai.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbb_TrangThai.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbb_TrangThai.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbb_TrangThai.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cbb_TrangThai.ItemHeight = 30;
            this.cbb_TrangThai.Location = new System.Drawing.Point(524, 65);
            this.cbb_TrangThai.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbb_TrangThai.Name = "cbb_TrangThai";
            this.cbb_TrangThai.Size = new System.Drawing.Size(255, 36);
            this.cbb_TrangThai.TabIndex = 47;
            // 
            // cbb_ChuKy
            // 
            this.cbb_ChuKy.BackColor = System.Drawing.Color.Transparent;
            this.cbb_ChuKy.BorderRadius = 10;
            this.cbb_ChuKy.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cbb_ChuKy.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbb_ChuKy.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbb_ChuKy.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbb_ChuKy.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbb_ChuKy.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cbb_ChuKy.ItemHeight = 30;
            this.cbb_ChuKy.Location = new System.Drawing.Point(524, 15);
            this.cbb_ChuKy.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbb_ChuKy.Name = "cbb_ChuKy";
            this.cbb_ChuKy.Size = new System.Drawing.Size(255, 36);
            this.cbb_ChuKy.TabIndex = 46;
            // 
            // lbldongia
            // 
            this.lbldongia.AutoSize = true;
            this.lbldongia.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldongia.ForeColor = System.Drawing.Color.Black;
            this.lbldongia.Location = new System.Drawing.Point(57, 123);
            this.lbldongia.Name = "lbldongia";
            this.lbldongia.Size = new System.Drawing.Size(65, 20);
            this.lbldongia.TabIndex = 42;
            this.lbldongia.Text = "Đơn giá:";
            // 
            // txt_DonGia
            // 
            this.txt_DonGia.BorderRadius = 10;
            this.txt_DonGia.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_DonGia.DefaultText = "";
            this.txt_DonGia.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_DonGia.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_DonGia.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_DonGia.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_DonGia.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_DonGia.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txt_DonGia.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_DonGia.Location = new System.Drawing.Point(143, 118);
            this.txt_DonGia.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_DonGia.Name = "txt_DonGia";
            this.txt_DonGia.PasswordChar = '\0';
            this.txt_DonGia.PlaceholderText = "";
            this.txt_DonGia.SelectedText = "";
            this.txt_DonGia.Size = new System.Drawing.Size(255, 36);
            this.txt_DonGia.TabIndex = 43;
            // 
            // lblchuky
            // 
            this.lblchuky.AutoSize = true;
            this.lblchuky.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblchuky.ForeColor = System.Drawing.Color.Black;
            this.lblchuky.Location = new System.Drawing.Point(457, 19);
            this.lblchuky.Name = "lblchuky";
            this.lblchuky.Size = new System.Drawing.Size(55, 20);
            this.lblchuky.TabIndex = 34;
            this.lblchuky.Text = "Chu kỳ:";
            // 
            // lbltrangthai
            // 
            this.lbltrangthai.AutoSize = true;
            this.lbltrangthai.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltrangthai.ForeColor = System.Drawing.Color.Black;
            this.lbltrangthai.Location = new System.Drawing.Point(436, 70);
            this.lbltrangthai.Name = "lbltrangthai";
            this.lbltrangthai.Size = new System.Drawing.Size(78, 20);
            this.lbltrangthai.TabIndex = 35;
            this.lbltrangthai.Text = "Trạng thái:";
            // 
            // txt_ID
            // 
            this.txt_ID.BorderRadius = 10;
            this.txt_ID.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_ID.DefaultText = "";
            this.txt_ID.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_ID.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_ID.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_ID.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_ID.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_ID.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txt_ID.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_ID.Location = new System.Drawing.Point(143, 15);
            this.txt_ID.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_ID.Name = "txt_ID";
            this.txt_ID.PasswordChar = '\0';
            this.txt_ID.PlaceholderText = "";
            this.txt_ID.SelectedText = "";
            this.txt_ID.Size = new System.Drawing.Size(255, 36);
            this.txt_ID.TabIndex = 37;
            // 
            // lblidkhoanphi
            // 
            this.lblidkhoanphi.AutoSize = true;
            this.lblidkhoanphi.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblidkhoanphi.ForeColor = System.Drawing.Color.Black;
            this.lblidkhoanphi.Location = new System.Drawing.Point(22, 21);
            this.lblidkhoanphi.Name = "lblidkhoanphi";
            this.lblidkhoanphi.Size = new System.Drawing.Size(96, 20);
            this.lblidkhoanphi.TabIndex = 32;
            this.lblidkhoanphi.Text = "ID khoản phí:";
            // 
            // lbltenkhoanphi
            // 
            this.lbltenkhoanphi.AutoSize = true;
            this.lbltenkhoanphi.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltenkhoanphi.ForeColor = System.Drawing.Color.Black;
            this.lbltenkhoanphi.Location = new System.Drawing.Point(15, 72);
            this.lbltenkhoanphi.Name = "lbltenkhoanphi";
            this.lbltenkhoanphi.Size = new System.Drawing.Size(104, 20);
            this.lbltenkhoanphi.TabIndex = 33;
            this.lbltenkhoanphi.Text = "Tên khoản phí:";
            // 
            // txt_Ten
            // 
            this.txt_Ten.BorderRadius = 10;
            this.txt_Ten.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_Ten.DefaultText = "";
            this.txt_Ten.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_Ten.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_Ten.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Ten.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Ten.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Ten.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txt_Ten.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Ten.Location = new System.Drawing.Point(143, 66);
            this.txt_Ten.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_Ten.Name = "txt_Ten";
            this.txt_Ten.PasswordChar = '\0';
            this.txt_Ten.PlaceholderText = "";
            this.txt_Ten.SelectedText = "";
            this.txt_Ten.Size = new System.Drawing.Size(255, 36);
            this.txt_Ten.TabIndex = 38;
            // 
            // ThemKhoanPhi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(820, 282);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.btn_Huy);
            this.Controls.Add(this.btn_Them);
            this.Controls.Add(this.guna2GroupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "ThemKhoanPhi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ThemChiPhi";
            this.Load += new System.EventHandler(this.ThemKhoanPhi_Load);
            this.guna2GroupBox1.ResumeLayout(false);
            this.guna2GroupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label6;
        private Guna.UI2.WinForms.Guna2Button btn_Huy;
        private Guna.UI2.WinForms.Guna2Button btn_Them;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox1;
        private System.Windows.Forms.Label lbldongia;
        private Guna.UI2.WinForms.Guna2TextBox txt_DonGia;
        private System.Windows.Forms.Label lblchuky;
        private System.Windows.Forms.Label lbltrangthai;
        private Guna.UI2.WinForms.Guna2TextBox txt_ID;
        private System.Windows.Forms.Label lblidkhoanphi;
        private System.Windows.Forms.Label lbltenkhoanphi;
        private Guna.UI2.WinForms.Guna2TextBox txt_Ten;
        private Guna.UI2.WinForms.Guna2ComboBox cbb_TrangThai;
        private Guna.UI2.WinForms.Guna2ComboBox cbb_ChuKy;
    }
}