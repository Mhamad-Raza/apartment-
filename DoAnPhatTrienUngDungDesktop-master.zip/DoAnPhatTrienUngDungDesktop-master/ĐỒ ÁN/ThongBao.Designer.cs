﻿namespace Đồ_án_desktop_2._0
{
    partial class ThongBao
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ThongBao));
            this.guna2GradientPanel8 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.guna2GradientPanel2 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.guna2GradientPanel6 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.guna2GradientPanel1 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.guna2Button10 = new Guna.UI2.WinForms.Guna2Button();
            this.btn_QLTK = new Guna.UI2.WinForms.Guna2Button();
            this.btn_QLDV = new Guna.UI2.WinForms.Guna2Button();
            this.btn_DangXuat = new Guna.UI2.WinForms.Guna2Button();
            this.btn_CSCD = new Guna.UI2.WinForms.Guna2Button();
            this.btn_QLTI = new Guna.UI2.WinForms.Guna2Button();
            this.btn_QLCP = new Guna.UI2.WinForms.Guna2Button();
            this.btn_QLCH = new Guna.UI2.WinForms.Guna2Button();
            this.btn_QLCDDD = new Guna.UI2.WinForms.Guna2Button();
            this.label1 = new System.Windows.Forms.Label();
            this.dgv_ThongBao = new System.Windows.Forms.DataGridView();
            this.guna2PictureBox2 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2HtmlLabel4 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.txt_keyword = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.label3 = new System.Windows.Forms.Label();
            this.guna2GradientPanel5 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.dtp_KT = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.dtp_BD = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.btn_Refresh = new Guna.UI2.WinForms.Guna2Button();
            this.btn_TraCuu = new Guna.UI2.WinForms.Guna2Button();
            this.label2 = new System.Windows.Forms.Label();
            this.guna2GradientPanel3 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.btn_ChinhSua = new Guna.UI2.WinForms.Guna2Button();
            this.btn_Them = new Guna.UI2.WinForms.Guna2Button();
            this.btn_Xoa = new Guna.UI2.WinForms.Guna2Button();
            this.guna2GradientPanel2.SuspendLayout();
            this.guna2GradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_ThongBao)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox2)).BeginInit();
            this.guna2GradientPanel5.SuspendLayout();
            this.guna2GradientPanel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2GradientPanel8
            // 
            this.guna2GradientPanel8.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientPanel8.FillColor = System.Drawing.Color.Gainsboro;
            this.guna2GradientPanel8.FillColor2 = System.Drawing.Color.WhiteSmoke;
            this.guna2GradientPanel8.Location = new System.Drawing.Point(217, 255);
            this.guna2GradientPanel8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2GradientPanel8.Name = "guna2GradientPanel8";
            this.guna2GradientPanel8.Size = new System.Drawing.Size(1089, 5);
            this.guna2GradientPanel8.TabIndex = 129;
            // 
            // guna2GradientPanel2
            // 
            this.guna2GradientPanel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientPanel2.Controls.Add(this.guna2GradientPanel6);
            this.guna2GradientPanel2.FillColor = System.Drawing.Color.White;
            this.guna2GradientPanel2.FillColor2 = System.Drawing.Color.LightGray;
            this.guna2GradientPanel2.Location = new System.Drawing.Point(208, -1);
            this.guna2GradientPanel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2GradientPanel2.Name = "guna2GradientPanel2";
            this.guna2GradientPanel2.Size = new System.Drawing.Size(10, 700);
            this.guna2GradientPanel2.TabIndex = 128;
            // 
            // guna2GradientPanel6
            // 
            this.guna2GradientPanel6.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientPanel6.FillColor = System.Drawing.Color.Gainsboro;
            this.guna2GradientPanel6.FillColor2 = System.Drawing.Color.WhiteSmoke;
            this.guna2GradientPanel6.Location = new System.Drawing.Point(9, 232);
            this.guna2GradientPanel6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2GradientPanel6.Name = "guna2GradientPanel6";
            this.guna2GradientPanel6.Size = new System.Drawing.Size(1089, 5);
            this.guna2GradientPanel6.TabIndex = 52;
            // 
            // guna2GradientPanel1
            // 
            this.guna2GradientPanel1.BackColor = System.Drawing.Color.White;
            this.guna2GradientPanel1.Controls.Add(this.guna2Button10);
            this.guna2GradientPanel1.Controls.Add(this.btn_QLTK);
            this.guna2GradientPanel1.Controls.Add(this.btn_QLDV);
            this.guna2GradientPanel1.Controls.Add(this.btn_DangXuat);
            this.guna2GradientPanel1.Controls.Add(this.btn_CSCD);
            this.guna2GradientPanel1.Controls.Add(this.btn_QLTI);
            this.guna2GradientPanel1.Controls.Add(this.btn_QLCP);
            this.guna2GradientPanel1.Controls.Add(this.btn_QLCH);
            this.guna2GradientPanel1.Controls.Add(this.btn_QLCDDD);
            this.guna2GradientPanel1.Location = new System.Drawing.Point(-2, -1);
            this.guna2GradientPanel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2GradientPanel1.Name = "guna2GradientPanel1";
            this.guna2GradientPanel1.Size = new System.Drawing.Size(212, 701);
            this.guna2GradientPanel1.TabIndex = 127;
            // 
            // guna2Button10
            // 
            this.guna2Button10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2Button10.BorderColor = System.Drawing.Color.Transparent;
            this.guna2Button10.BorderThickness = 1;
            this.guna2Button10.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button10.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button10.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button10.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button10.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button10.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.guna2Button10.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.guna2Button10.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button10.Image")));
            this.guna2Button10.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button10.ImageSize = new System.Drawing.Size(30, 30);
            this.guna2Button10.Location = new System.Drawing.Point(0, 348);
            this.guna2Button10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button10.Name = "guna2Button10";
            this.guna2Button10.Size = new System.Drawing.Size(213, 50);
            this.guna2Button10.TabIndex = 10;
            this.guna2Button10.Text = "Thông báo";
            this.guna2Button10.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // btn_QLTK
            // 
            this.btn_QLTK.BackColor = System.Drawing.Color.Transparent;
            this.btn_QLTK.BorderColor = System.Drawing.Color.Transparent;
            this.btn_QLTK.BorderThickness = 1;
            this.btn_QLTK.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLTK.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLTK.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_QLTK.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_QLTK.FillColor = System.Drawing.Color.Transparent;
            this.btn_QLTK.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_QLTK.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_QLTK.Image = ((System.Drawing.Image)(resources.GetObject("btn_QLTK.Image")));
            this.btn_QLTK.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLTK.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_QLTK.Location = new System.Drawing.Point(0, 198);
            this.btn_QLTK.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_QLTK.Name = "btn_QLTK";
            this.btn_QLTK.Size = new System.Drawing.Size(213, 50);
            this.btn_QLTK.TabIndex = 9;
            this.btn_QLTK.Text = "Quản lý tài khoản";
            this.btn_QLTK.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLTK.Click += new System.EventHandler(this.btn_QLTK_Click);
            // 
            // btn_QLDV
            // 
            this.btn_QLDV.BackColor = System.Drawing.Color.Transparent;
            this.btn_QLDV.BorderColor = System.Drawing.Color.Transparent;
            this.btn_QLDV.BorderThickness = 1;
            this.btn_QLDV.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLDV.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLDV.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_QLDV.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_QLDV.FillColor = System.Drawing.Color.Transparent;
            this.btn_QLDV.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_QLDV.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_QLDV.Image = ((System.Drawing.Image)(resources.GetObject("btn_QLDV.Image")));
            this.btn_QLDV.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLDV.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_QLDV.Location = new System.Drawing.Point(0, 98);
            this.btn_QLDV.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_QLDV.Name = "btn_QLDV";
            this.btn_QLDV.Size = new System.Drawing.Size(213, 50);
            this.btn_QLDV.TabIndex = 8;
            this.btn_QLDV.Text = "Quản lý dịch vụ";
            this.btn_QLDV.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLDV.Click += new System.EventHandler(this.btn_QLDV_Click);
            // 
            // btn_DangXuat
            // 
            this.btn_DangXuat.BackColor = System.Drawing.Color.Transparent;
            this.btn_DangXuat.BorderColor = System.Drawing.Color.Transparent;
            this.btn_DangXuat.BorderThickness = 2;
            this.btn_DangXuat.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_DangXuat.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_DangXuat.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_DangXuat.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_DangXuat.FillColor = System.Drawing.Color.Transparent;
            this.btn_DangXuat.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_DangXuat.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_DangXuat.Image = ((System.Drawing.Image)(resources.GetObject("btn_DangXuat.Image")));
            this.btn_DangXuat.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_DangXuat.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_DangXuat.Location = new System.Drawing.Point(1, 657);
            this.btn_DangXuat.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_DangXuat.Name = "btn_DangXuat";
            this.btn_DangXuat.Size = new System.Drawing.Size(213, 41);
            this.btn_DangXuat.TabIndex = 7;
            this.btn_DangXuat.Text = "Đăng xuất";
            this.btn_DangXuat.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_DangXuat.Click += new System.EventHandler(this.btn_DangXuat_Click);
            // 
            // btn_CSCD
            // 
            this.btn_CSCD.BackColor = System.Drawing.Color.Transparent;
            this.btn_CSCD.BorderColor = System.Drawing.Color.Transparent;
            this.btn_CSCD.BorderThickness = 1;
            this.btn_CSCD.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_CSCD.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_CSCD.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_CSCD.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_CSCD.FillColor = System.Drawing.Color.Transparent;
            this.btn_CSCD.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_CSCD.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_CSCD.Image = ((System.Drawing.Image)(resources.GetObject("btn_CSCD.Image")));
            this.btn_CSCD.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_CSCD.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_CSCD.Location = new System.Drawing.Point(0, -2);
            this.btn_CSCD.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_CSCD.Name = "btn_CSCD";
            this.btn_CSCD.Size = new System.Drawing.Size(213, 50);
            this.btn_CSCD.TabIndex = 1;
            this.btn_CSCD.Text = "Chăm sóc cư dân";
            this.btn_CSCD.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_CSCD.Click += new System.EventHandler(this.btn_CSCD_Click);
            // 
            // btn_QLTI
            // 
            this.btn_QLTI.BackColor = System.Drawing.Color.Transparent;
            this.btn_QLTI.BorderColor = System.Drawing.Color.Transparent;
            this.btn_QLTI.BorderThickness = 1;
            this.btn_QLTI.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLTI.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLTI.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_QLTI.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_QLTI.FillColor = System.Drawing.Color.Transparent;
            this.btn_QLTI.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_QLTI.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_QLTI.Image = ((System.Drawing.Image)(resources.GetObject("btn_QLTI.Image")));
            this.btn_QLTI.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLTI.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_QLTI.Location = new System.Drawing.Point(0, 48);
            this.btn_QLTI.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_QLTI.Name = "btn_QLTI";
            this.btn_QLTI.Size = new System.Drawing.Size(213, 50);
            this.btn_QLTI.TabIndex = 2;
            this.btn_QLTI.Text = "Quản lý tiện ích";
            this.btn_QLTI.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLTI.Click += new System.EventHandler(this.btn_QLTI_Click);
            // 
            // btn_QLCP
            // 
            this.btn_QLCP.BackColor = System.Drawing.Color.Transparent;
            this.btn_QLCP.BorderColor = System.Drawing.Color.Transparent;
            this.btn_QLCP.BorderThickness = 1;
            this.btn_QLCP.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLCP.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLCP.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_QLCP.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_QLCP.FillColor = System.Drawing.Color.Transparent;
            this.btn_QLCP.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_QLCP.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_QLCP.Image = ((System.Drawing.Image)(resources.GetObject("btn_QLCP.Image")));
            this.btn_QLCP.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLCP.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_QLCP.Location = new System.Drawing.Point(0, 298);
            this.btn_QLCP.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_QLCP.Name = "btn_QLCP";
            this.btn_QLCP.Size = new System.Drawing.Size(213, 50);
            this.btn_QLCP.TabIndex = 5;
            this.btn_QLCP.Text = "Quản lý khoản phí";
            this.btn_QLCP.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLCP.Click += new System.EventHandler(this.btn_QLCP_Click);
            // 
            // btn_QLCH
            // 
            this.btn_QLCH.BackColor = System.Drawing.Color.Transparent;
            this.btn_QLCH.BorderColor = System.Drawing.Color.Transparent;
            this.btn_QLCH.BorderThickness = 1;
            this.btn_QLCH.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLCH.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLCH.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_QLCH.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_QLCH.FillColor = System.Drawing.Color.Transparent;
            this.btn_QLCH.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_QLCH.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_QLCH.Image = ((System.Drawing.Image)(resources.GetObject("btn_QLCH.Image")));
            this.btn_QLCH.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLCH.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_QLCH.Location = new System.Drawing.Point(0, 148);
            this.btn_QLCH.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_QLCH.Name = "btn_QLCH";
            this.btn_QLCH.Size = new System.Drawing.Size(213, 50);
            this.btn_QLCH.TabIndex = 3;
            this.btn_QLCH.Text = "Quản lý căn hộ";
            this.btn_QLCH.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLCH.Click += new System.EventHandler(this.btn_QLCH_Click);
            // 
            // btn_QLCDDD
            // 
            this.btn_QLCDDD.BackColor = System.Drawing.Color.Transparent;
            this.btn_QLCDDD.BorderColor = System.Drawing.Color.Transparent;
            this.btn_QLCDDD.BorderThickness = 1;
            this.btn_QLCDDD.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLCDDD.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLCDDD.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_QLCDDD.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_QLCDDD.FillColor = System.Drawing.Color.Transparent;
            this.btn_QLCDDD.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_QLCDDD.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_QLCDDD.Image = ((System.Drawing.Image)(resources.GetObject("btn_QLCDDD.Image")));
            this.btn_QLCDDD.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLCDDD.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_QLCDDD.Location = new System.Drawing.Point(0, 248);
            this.btn_QLCDDD.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_QLCDDD.Name = "btn_QLCDDD";
            this.btn_QLCDDD.Size = new System.Drawing.Size(213, 50);
            this.btn_QLCDDD.TabIndex = 4;
            this.btn_QLCDDD.Text = "Quản lý cư dân đại diện";
            this.btn_QLCDDD.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLCDDD.Click += new System.EventHandler(this.btn_QLCDDD_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DimGray;
            this.label1.Location = new System.Drawing.Point(266, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(152, 26);
            this.label1.TabIndex = 121;
            this.label1.Text = "THÔNG BÁO";
            // 
            // dgv_ThongBao
            // 
            this.dgv_ThongBao.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_ThongBao.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgv_ThongBao.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgv_ThongBao.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_ThongBao.Location = new System.Drawing.Point(215, 257);
            this.dgv_ThongBao.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dgv_ThongBao.Name = "dgv_ThongBao";
            this.dgv_ThongBao.RowHeadersWidth = 62;
            this.dgv_ThongBao.RowTemplate.Height = 28;
            this.dgv_ThongBao.Size = new System.Drawing.Size(1091, 442);
            this.dgv_ThongBao.TabIndex = 131;
            // 
            // guna2PictureBox2
            // 
            this.guna2PictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox2.ErrorImage = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox2.ErrorImage")));
            this.guna2PictureBox2.Image = global::ĐỒ_ÁN.Properties.Resources.logo;
            this.guna2PictureBox2.ImageRotate = 0F;
            this.guna2PictureBox2.Location = new System.Drawing.Point(215, 8);
            this.guna2PictureBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2PictureBox2.Name = "guna2PictureBox2";
            this.guna2PictureBox2.Size = new System.Drawing.Size(60, 38);
            this.guna2PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox2.TabIndex = 130;
            this.guna2PictureBox2.TabStop = false;
            // 
            // guna2HtmlLabel4
            // 
            this.guna2HtmlLabel4.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2HtmlLabel4.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel4.Location = new System.Drawing.Point(13, 114);
            this.guna2HtmlLabel4.Name = "guna2HtmlLabel4";
            this.guna2HtmlLabel4.Padding = new System.Windows.Forms.Padding(5);
            this.guna2HtmlLabel4.Size = new System.Drawing.Size(122, 37);
            this.guna2HtmlLabel4.TabIndex = 162;
            this.guna2HtmlLabel4.Text = "Nhập từ khóa";
            // 
            // txt_keyword
            // 
            this.txt_keyword.BorderRadius = 10;
            this.txt_keyword.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_keyword.DefaultText = "";
            this.txt_keyword.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_keyword.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_keyword.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_keyword.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_keyword.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_keyword.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txt_keyword.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_keyword.Location = new System.Drawing.Point(840, 180);
            this.txt_keyword.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_keyword.Name = "txt_keyword";
            this.txt_keyword.PasswordChar = '\0';
            this.txt_keyword.PlaceholderText = "";
            this.txt_keyword.SelectedText = "";
            this.txt_keyword.Size = new System.Drawing.Size(279, 39);
            this.txt_keyword.TabIndex = 159;
            // 
            // guna2HtmlLabel2
            // 
            this.guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2HtmlLabel2.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel2.Location = new System.Drawing.Point(13, 16);
            this.guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            this.guna2HtmlLabel2.Padding = new System.Windows.Forms.Padding(5);
            this.guna2HtmlLabel2.Size = new System.Drawing.Size(33, 37);
            this.guna2HtmlLabel2.TabIndex = 160;
            this.guna2HtmlLabel2.Text = "Từ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DimGray;
            this.label3.Location = new System.Drawing.Point(720, 52);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(125, 29);
            this.label3.TabIndex = 158;
            this.label3.Text = "TRA CỨU";
            // 
            // guna2GradientPanel5
            // 
            this.guna2GradientPanel5.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientPanel5.BorderColor = System.Drawing.Color.Silver;
            this.guna2GradientPanel5.BorderRadius = 10;
            this.guna2GradientPanel5.BorderThickness = 2;
            this.guna2GradientPanel5.Controls.Add(this.dtp_KT);
            this.guna2GradientPanel5.Controls.Add(this.dtp_BD);
            this.guna2GradientPanel5.Controls.Add(this.guna2HtmlLabel4);
            this.guna2GradientPanel5.Controls.Add(this.guna2HtmlLabel1);
            this.guna2GradientPanel5.Controls.Add(this.btn_Refresh);
            this.guna2GradientPanel5.Controls.Add(this.btn_TraCuu);
            this.guna2GradientPanel5.Controls.Add(this.guna2HtmlLabel2);
            this.guna2GradientPanel5.Location = new System.Drawing.Point(699, 66);
            this.guna2GradientPanel5.Name = "guna2GradientPanel5";
            this.guna2GradientPanel5.Size = new System.Drawing.Size(593, 171);
            this.guna2GradientPanel5.TabIndex = 163;
            // 
            // dtp_KT
            // 
            this.dtp_KT.BackColor = System.Drawing.SystemColors.Control;
            this.dtp_KT.BorderRadius = 10;
            this.dtp_KT.Checked = true;
            this.dtp_KT.FillColor = System.Drawing.SystemColors.Control;
            this.dtp_KT.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.dtp_KT.ForeColor = System.Drawing.Color.Black;
            this.dtp_KT.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.dtp_KT.Location = new System.Drawing.Point(75, 66);
            this.dtp_KT.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtp_KT.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtp_KT.Name = "dtp_KT";
            this.dtp_KT.Size = new System.Drawing.Size(345, 36);
            this.dtp_KT.TabIndex = 167;
            this.dtp_KT.Value = new System.DateTime(2024, 12, 19, 3, 43, 16, 0);
            this.dtp_KT.ValueChanged += new System.EventHandler(this.dtp_KT_ValueChanged);
            // 
            // dtp_BD
            // 
            this.dtp_BD.BackColor = System.Drawing.SystemColors.Control;
            this.dtp_BD.BorderRadius = 10;
            this.dtp_BD.Checked = true;
            this.dtp_BD.FillColor = System.Drawing.SystemColors.Control;
            this.dtp_BD.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.dtp_BD.ForeColor = System.Drawing.Color.Black;
            this.dtp_BD.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.dtp_BD.Location = new System.Drawing.Point(75, 18);
            this.dtp_BD.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtp_BD.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtp_BD.Name = "dtp_BD";
            this.dtp_BD.Size = new System.Drawing.Size(345, 36);
            this.dtp_BD.TabIndex = 166;
            this.dtp_BD.Value = new System.DateTime(2024, 12, 19, 3, 43, 16, 0);
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2HtmlLabel1.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(13, 65);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Padding = new System.Windows.Forms.Padding(5);
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(45, 37);
            this.guna2HtmlLabel1.TabIndex = 164;
            this.guna2HtmlLabel1.Text = "Đến";
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Refresh.BackgroundImage")));
            this.btn_Refresh.BorderRadius = 10;
            this.btn_Refresh.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_Refresh.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_Refresh.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_Refresh.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_Refresh.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Refresh.ForeColor = System.Drawing.Color.Violet;
            this.btn_Refresh.Image = ((System.Drawing.Image)(resources.GetObject("btn_Refresh.Image")));
            this.btn_Refresh.IndicateFocus = true;
            this.btn_Refresh.Location = new System.Drawing.Point(514, 18);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(68, 136);
            this.btn_Refresh.TabIndex = 32;
            this.btn_Refresh.Click += new System.EventHandler(this.btn_Refresh_Click);
            // 
            // btn_TraCuu
            // 
            this.btn_TraCuu.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_TraCuu.BackgroundImage")));
            this.btn_TraCuu.BorderRadius = 10;
            this.btn_TraCuu.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_TraCuu.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_TraCuu.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_TraCuu.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_TraCuu.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_TraCuu.ForeColor = System.Drawing.Color.Violet;
            this.btn_TraCuu.Image = ((System.Drawing.Image)(resources.GetObject("btn_TraCuu.Image")));
            this.btn_TraCuu.IndicateFocus = true;
            this.btn_TraCuu.Location = new System.Drawing.Point(437, 18);
            this.btn_TraCuu.Name = "btn_TraCuu";
            this.btn_TraCuu.Size = new System.Drawing.Size(68, 136);
            this.btn_TraCuu.TabIndex = 31;
            this.btn_TraCuu.Click += new System.EventHandler(this.btn_TraCuu_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DimGray;
            this.label2.Location = new System.Drawing.Point(243, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(229, 29);
            this.label2.TabIndex = 152;
            this.label2.Text = "THAO TÁC CHÍNH";
            // 
            // guna2GradientPanel3
            // 
            this.guna2GradientPanel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientPanel3.BorderColor = System.Drawing.Color.Silver;
            this.guna2GradientPanel3.BorderRadius = 10;
            this.guna2GradientPanel3.BorderThickness = 2;
            this.guna2GradientPanel3.Controls.Add(this.btn_ChinhSua);
            this.guna2GradientPanel3.Controls.Add(this.btn_Them);
            this.guna2GradientPanel3.Controls.Add(this.btn_Xoa);
            this.guna2GradientPanel3.Location = new System.Drawing.Point(230, 66);
            this.guna2GradientPanel3.Name = "guna2GradientPanel3";
            this.guna2GradientPanel3.Size = new System.Drawing.Size(454, 171);
            this.guna2GradientPanel3.TabIndex = 153;
            // 
            // btn_ChinhSua
            // 
            this.btn_ChinhSua.BorderRadius = 10;
            this.btn_ChinhSua.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_ChinhSua.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_ChinhSua.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_ChinhSua.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_ChinhSua.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ChinhSua.ForeColor = System.Drawing.Color.White;
            this.btn_ChinhSua.Location = new System.Drawing.Point(169, 50);
            this.btn_ChinhSua.Name = "btn_ChinhSua";
            this.btn_ChinhSua.Size = new System.Drawing.Size(116, 70);
            this.btn_ChinhSua.TabIndex = 15;
            this.btn_ChinhSua.Text = "Sửa";
            this.btn_ChinhSua.Click += new System.EventHandler(this.btn_ChinhSua_Click);
            // 
            // btn_Them
            // 
            this.btn_Them.BorderRadius = 10;
            this.btn_Them.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_Them.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_Them.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_Them.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_Them.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Them.ForeColor = System.Drawing.Color.White;
            this.btn_Them.Location = new System.Drawing.Point(23, 50);
            this.btn_Them.Name = "btn_Them";
            this.btn_Them.Size = new System.Drawing.Size(116, 70);
            this.btn_Them.TabIndex = 14;
            this.btn_Them.Text = "Thêm";
            this.btn_Them.Click += new System.EventHandler(this.btn_Them_Click);
            // 
            // btn_Xoa
            // 
            this.btn_Xoa.BorderRadius = 10;
            this.btn_Xoa.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_Xoa.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_Xoa.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_Xoa.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_Xoa.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btn_Xoa.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Xoa.ForeColor = System.Drawing.Color.White;
            this.btn_Xoa.Location = new System.Drawing.Point(315, 50);
            this.btn_Xoa.Name = "btn_Xoa";
            this.btn_Xoa.Size = new System.Drawing.Size(116, 70);
            this.btn_Xoa.TabIndex = 16;
            this.btn_Xoa.Text = "Xóa";
            this.btn_Xoa.Click += new System.EventHandler(this.btn_Xoa_Click);
            // 
            // ThongBao
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.ClientSize = new System.Drawing.Size(1304, 699);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.guna2GradientPanel8);
            this.Controls.Add(this.txt_keyword);
            this.Controls.Add(this.guna2GradientPanel2);
            this.Controls.Add(this.guna2GradientPanel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dgv_ThongBao);
            this.Controls.Add(this.guna2GradientPanel5);
            this.Controls.Add(this.guna2PictureBox2);
            this.Controls.Add(this.guna2GradientPanel3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "ThongBao";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ThongBao";
            this.Load += new System.EventHandler(this.ThongBao_Load);
            this.guna2GradientPanel2.ResumeLayout(false);
            this.guna2GradientPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_ThongBao)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox2)).EndInit();
            this.guna2GradientPanel5.ResumeLayout(false);
            this.guna2GradientPanel5.PerformLayout();
            this.guna2GradientPanel3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel8;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel2;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel6;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel1;
        private Guna.UI2.WinForms.Guna2Button btn_QLTK;
        private Guna.UI2.WinForms.Guna2Button btn_QLDV;
        private Guna.UI2.WinForms.Guna2Button btn_DangXuat;
        private Guna.UI2.WinForms.Guna2Button btn_CSCD;
        private Guna.UI2.WinForms.Guna2Button btn_QLTI;
        private Guna.UI2.WinForms.Guna2Button btn_QLCP;
        private Guna.UI2.WinForms.Guna2Button btn_QLCH;
        private Guna.UI2.WinForms.Guna2Button btn_QLCDDD;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgv_ThongBao;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox2;
        private Guna.UI2.WinForms.Guna2Button guna2Button10;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel4;
        private Guna.UI2.WinForms.Guna2TextBox txt_keyword;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel5;
        private Guna.UI2.WinForms.Guna2Button btn_Refresh;
        private Guna.UI2.WinForms.Guna2Button btn_TraCuu;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel3;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2DateTimePicker dtp_BD;
        private Guna.UI2.WinForms.Guna2DateTimePicker dtp_KT;
        private Guna.UI2.WinForms.Guna2Button btn_ChinhSua;
        private Guna.UI2.WinForms.Guna2Button btn_Them;
        private Guna.UI2.WinForms.Guna2Button btn_Xoa;
    }
}