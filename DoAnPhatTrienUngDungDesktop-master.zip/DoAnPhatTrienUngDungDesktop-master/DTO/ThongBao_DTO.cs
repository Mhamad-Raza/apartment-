﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class ThongBao_DTO
    {
        public string ID_ThongBao { get; set; }
        public string NguoiGui { get; set; }
        public string TieuDe { get; set; }
        public string NoiDung { get; set; }
        public string NgayGui { get; set; }
        public string TrangThai { get; set; }
    }
}
