﻿namespace Đồ_án_desktop_2._0
{
    partial class ChamSocCuDan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ChamSocCuDan));
            this.btn_PhanHoi = new Guna.UI2.WinForms.Guna2Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.guna2GradientPanel3 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.btn_PhanCong = new Guna.UI2.WinForms.Guna2Button();
            this.label3 = new System.Windows.Forms.Label();
            this.guna2HtmlLabel4 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.txt_keyword = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.cbb_LoaiKhieuNai = new Guna.UI2.WinForms.Guna2ComboBox();
            this.guna2GradientPanel5 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.btn_Refresh = new Guna.UI2.WinForms.Guna2Button();
            this.btn_TraCuu = new Guna.UI2.WinForms.Guna2Button();
            this.guna2GradientPanel2 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.guna2GradientPanel6 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.dgv_KhieuNai = new System.Windows.Forms.DataGridView();
            this.guna2GradientPanel8 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.guna2GradientPanel1 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.btn_TB = new Guna.UI2.WinForms.Guna2Button();
            this.btn_QLTK = new Guna.UI2.WinForms.Guna2Button();
            this.btn_QLDV = new Guna.UI2.WinForms.Guna2Button();
            this.btn_DangXuat = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.btn_QLTI = new Guna.UI2.WinForms.Guna2Button();
            this.btn_QLCP = new Guna.UI2.WinForms.Guna2Button();
            this.btn_QLCH = new Guna.UI2.WinForms.Guna2Button();
            this.btn_QLCDDD = new Guna.UI2.WinForms.Guna2Button();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2GradientPanel3.SuspendLayout();
            this.guna2GradientPanel5.SuspendLayout();
            this.guna2GradientPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_KhieuNai)).BeginInit();
            this.guna2GradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_PhanHoi
            // 
            this.btn_PhanHoi.BorderRadius = 10;
            this.btn_PhanHoi.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_PhanHoi.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_PhanHoi.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_PhanHoi.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_PhanHoi.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_PhanHoi.ForeColor = System.Drawing.Color.White;
            this.btn_PhanHoi.Location = new System.Drawing.Point(63, 35);
            this.btn_PhanHoi.Name = "btn_PhanHoi";
            this.btn_PhanHoi.Size = new System.Drawing.Size(127, 70);
            this.btn_PhanHoi.TabIndex = 10;
            this.btn_PhanHoi.Text = "Phản hồi";
            this.btn_PhanHoi.Click += new System.EventHandler(this.btnPhanHoi_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DimGray;
            this.label1.Location = new System.Drawing.Point(279, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(237, 26);
            this.label1.TabIndex = 17;
            this.label1.Text = "CHĂM SÓC CƯ DÂN";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DimGray;
            this.label2.Location = new System.Drawing.Point(265, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(229, 29);
            this.label2.TabIndex = 19;
            this.label2.Text = "THAO TÁC CHÍNH";
            // 
            // guna2GradientPanel3
            // 
            this.guna2GradientPanel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientPanel3.BorderColor = System.Drawing.Color.Silver;
            this.guna2GradientPanel3.BorderRadius = 10;
            this.guna2GradientPanel3.BorderThickness = 2;
            this.guna2GradientPanel3.Controls.Add(this.btn_PhanCong);
            this.guna2GradientPanel3.Controls.Add(this.btn_PhanHoi);
            this.guna2GradientPanel3.Location = new System.Drawing.Point(252, 71);
            this.guna2GradientPanel3.Name = "guna2GradientPanel3";
            this.guna2GradientPanel3.Size = new System.Drawing.Size(458, 133);
            this.guna2GradientPanel3.TabIndex = 20;
            // 
            // btn_PhanCong
            // 
            this.btn_PhanCong.BorderRadius = 10;
            this.btn_PhanCong.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_PhanCong.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_PhanCong.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_PhanCong.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_PhanCong.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_PhanCong.ForeColor = System.Drawing.Color.White;
            this.btn_PhanCong.Location = new System.Drawing.Point(266, 35);
            this.btn_PhanCong.Name = "btn_PhanCong";
            this.btn_PhanCong.Size = new System.Drawing.Size(127, 70);
            this.btn_PhanCong.TabIndex = 11;
            this.btn_PhanCong.Text = "Phân công";
            this.btn_PhanCong.Click += new System.EventHandler(this.btnPhanCong_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DimGray;
            this.label3.Location = new System.Drawing.Point(754, 59);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(125, 29);
            this.label3.TabIndex = 21;
            this.label3.Text = "TRA CỨU";
            // 
            // guna2HtmlLabel4
            // 
            this.guna2HtmlLabel4.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2HtmlLabel4.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel4.Location = new System.Drawing.Point(19, 78);
            this.guna2HtmlLabel4.Name = "guna2HtmlLabel4";
            this.guna2HtmlLabel4.Padding = new System.Windows.Forms.Padding(5);
            this.guna2HtmlLabel4.Size = new System.Drawing.Size(122, 37);
            this.guna2HtmlLabel4.TabIndex = 25;
            this.guna2HtmlLabel4.Text = "Nhập từ khóa";
            // 
            // txt_keyword
            // 
            this.txt_keyword.BorderRadius = 10;
            this.txt_keyword.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_keyword.DefaultText = "";
            this.txt_keyword.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_keyword.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_keyword.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_keyword.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_keyword.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_keyword.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txt_keyword.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_keyword.Location = new System.Drawing.Point(144, 76);
            this.txt_keyword.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_keyword.Name = "txt_keyword";
            this.txt_keyword.PasswordChar = '\0';
            this.txt_keyword.PlaceholderText = "";
            this.txt_keyword.SelectedText = "";
            this.txt_keyword.Size = new System.Drawing.Size(235, 39);
            this.txt_keyword.TabIndex = 22;
            // 
            // guna2HtmlLabel2
            // 
            this.guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2HtmlLabel2.ForeColor = System.Drawing.Color.DarkGray;
            this.guna2HtmlLabel2.Location = new System.Drawing.Point(44, 23);
            this.guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            this.guna2HtmlLabel2.Padding = new System.Windows.Forms.Padding(5);
            this.guna2HtmlLabel2.Size = new System.Drawing.Size(92, 37);
            this.guna2HtmlLabel2.TabIndex = 23;
            this.guna2HtmlLabel2.Text = "Trạng thái";
            // 
            // cbb_LoaiKhieuNai
            // 
            this.cbb_LoaiKhieuNai.BackColor = System.Drawing.Color.Transparent;
            this.cbb_LoaiKhieuNai.BorderRadius = 10;
            this.cbb_LoaiKhieuNai.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cbb_LoaiKhieuNai.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbb_LoaiKhieuNai.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbb_LoaiKhieuNai.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbb_LoaiKhieuNai.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cbb_LoaiKhieuNai.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cbb_LoaiKhieuNai.ItemHeight = 30;
            this.cbb_LoaiKhieuNai.Items.AddRange(new object[] {
            "Chờ phản hồi",
            "Đang xử lý",
            "Đã hoàn tất"});
            this.cbb_LoaiKhieuNai.Location = new System.Drawing.Point(142, 24);
            this.cbb_LoaiKhieuNai.Name = "cbb_LoaiKhieuNai";
            this.cbb_LoaiKhieuNai.Size = new System.Drawing.Size(235, 36);
            this.cbb_LoaiKhieuNai.TabIndex = 24;
            // 
            // guna2GradientPanel5
            // 
            this.guna2GradientPanel5.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientPanel5.BorderColor = System.Drawing.Color.Silver;
            this.guna2GradientPanel5.BorderRadius = 10;
            this.guna2GradientPanel5.BorderThickness = 2;
            this.guna2GradientPanel5.Controls.Add(this.btn_Refresh);
            this.guna2GradientPanel5.Controls.Add(this.btn_TraCuu);
            this.guna2GradientPanel5.Controls.Add(this.cbb_LoaiKhieuNai);
            this.guna2GradientPanel5.Controls.Add(this.guna2HtmlLabel2);
            this.guna2GradientPanel5.Controls.Add(this.guna2HtmlLabel4);
            this.guna2GradientPanel5.Controls.Add(this.txt_keyword);
            this.guna2GradientPanel5.Location = new System.Drawing.Point(733, 72);
            this.guna2GradientPanel5.Name = "guna2GradientPanel5";
            this.guna2GradientPanel5.Size = new System.Drawing.Size(559, 134);
            this.guna2GradientPanel5.TabIndex = 28;
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Refresh.BackgroundImage")));
            this.btn_Refresh.BorderRadius = 10;
            this.btn_Refresh.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_Refresh.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_Refresh.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_Refresh.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_Refresh.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Refresh.ForeColor = System.Drawing.Color.Violet;
            this.btn_Refresh.Image = ((System.Drawing.Image)(resources.GetObject("btn_Refresh.Image")));
            this.btn_Refresh.IndicateFocus = true;
            this.btn_Refresh.Location = new System.Drawing.Point(473, 23);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(68, 92);
            this.btn_Refresh.TabIndex = 32;
            this.btn_Refresh.Click += new System.EventHandler(this.btn_Refresh_Click);
            // 
            // btn_TraCuu
            // 
            this.btn_TraCuu.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_TraCuu.BackgroundImage")));
            this.btn_TraCuu.BorderRadius = 10;
            this.btn_TraCuu.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_TraCuu.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_TraCuu.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_TraCuu.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_TraCuu.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_TraCuu.ForeColor = System.Drawing.Color.Violet;
            this.btn_TraCuu.Image = ((System.Drawing.Image)(resources.GetObject("btn_TraCuu.Image")));
            this.btn_TraCuu.IndicateFocus = true;
            this.btn_TraCuu.Location = new System.Drawing.Point(391, 23);
            this.btn_TraCuu.Name = "btn_TraCuu";
            this.btn_TraCuu.Size = new System.Drawing.Size(68, 92);
            this.btn_TraCuu.TabIndex = 31;
            this.btn_TraCuu.Click += new System.EventHandler(this.btn_TraCuu_Click);
            // 
            // guna2GradientPanel2
            // 
            this.guna2GradientPanel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientPanel2.Controls.Add(this.guna2GradientPanel6);
            this.guna2GradientPanel2.FillColor = System.Drawing.Color.White;
            this.guna2GradientPanel2.FillColor2 = System.Drawing.Color.LightGray;
            this.guna2GradientPanel2.Location = new System.Drawing.Point(208, 0);
            this.guna2GradientPanel2.Name = "guna2GradientPanel2";
            this.guna2GradientPanel2.Size = new System.Drawing.Size(10, 700);
            this.guna2GradientPanel2.TabIndex = 51;
            // 
            // guna2GradientPanel6
            // 
            this.guna2GradientPanel6.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientPanel6.FillColor = System.Drawing.Color.Gainsboro;
            this.guna2GradientPanel6.FillColor2 = System.Drawing.Color.WhiteSmoke;
            this.guna2GradientPanel6.Location = new System.Drawing.Point(9, 232);
            this.guna2GradientPanel6.Name = "guna2GradientPanel6";
            this.guna2GradientPanel6.Size = new System.Drawing.Size(1089, 5);
            this.guna2GradientPanel6.TabIndex = 52;
            // 
            // dgv_KhieuNai
            // 
            this.dgv_KhieuNai.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_KhieuNai.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgv_KhieuNai.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgv_KhieuNai.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_KhieuNai.Location = new System.Drawing.Point(215, 220);
            this.dgv_KhieuNai.Name = "dgv_KhieuNai";
            this.dgv_KhieuNai.ReadOnly = true;
            this.dgv_KhieuNai.RowHeadersWidth = 62;
            this.dgv_KhieuNai.RowTemplate.Height = 28;
            this.dgv_KhieuNai.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_KhieuNai.Size = new System.Drawing.Size(1091, 480);
            this.dgv_KhieuNai.TabIndex = 53;
            // 
            // guna2GradientPanel8
            // 
            this.guna2GradientPanel8.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientPanel8.FillColor = System.Drawing.Color.Gainsboro;
            this.guna2GradientPanel8.FillColor2 = System.Drawing.Color.WhiteSmoke;
            this.guna2GradientPanel8.Location = new System.Drawing.Point(217, 217);
            this.guna2GradientPanel8.Name = "guna2GradientPanel8";
            this.guna2GradientPanel8.Size = new System.Drawing.Size(1089, 5);
            this.guna2GradientPanel8.TabIndex = 52;
            // 
            // guna2GradientPanel1
            // 
            this.guna2GradientPanel1.BackColor = System.Drawing.Color.White;
            this.guna2GradientPanel1.Controls.Add(this.btn_TB);
            this.guna2GradientPanel1.Controls.Add(this.btn_QLTK);
            this.guna2GradientPanel1.Controls.Add(this.btn_QLDV);
            this.guna2GradientPanel1.Controls.Add(this.btn_DangXuat);
            this.guna2GradientPanel1.Controls.Add(this.guna2Button1);
            this.guna2GradientPanel1.Controls.Add(this.btn_QLTI);
            this.guna2GradientPanel1.Controls.Add(this.btn_QLCP);
            this.guna2GradientPanel1.Controls.Add(this.btn_QLCH);
            this.guna2GradientPanel1.Controls.Add(this.btn_QLCDDD);
            this.guna2GradientPanel1.Location = new System.Drawing.Point(-2, -1);
            this.guna2GradientPanel1.Name = "guna2GradientPanel1";
            this.guna2GradientPanel1.Size = new System.Drawing.Size(211, 701);
            this.guna2GradientPanel1.TabIndex = 82;
            // 
            // btn_TB
            // 
            this.btn_TB.BackColor = System.Drawing.Color.White;
            this.btn_TB.BorderColor = System.Drawing.Color.Transparent;
            this.btn_TB.BorderThickness = 1;
            this.btn_TB.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_TB.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_TB.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_TB.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_TB.FillColor = System.Drawing.Color.Transparent;
            this.btn_TB.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_TB.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_TB.Image = ((System.Drawing.Image)(resources.GetObject("btn_TB.Image")));
            this.btn_TB.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_TB.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_TB.Location = new System.Drawing.Point(-2, 359);
            this.btn_TB.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_TB.Name = "btn_TB";
            this.btn_TB.Size = new System.Drawing.Size(213, 50);
            this.btn_TB.TabIndex = 88;
            this.btn_TB.Text = "Thông báo";
            this.btn_TB.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_TB.Click += new System.EventHandler(this.btn_TB_Click);
            // 
            // btn_QLTK
            // 
            this.btn_QLTK.BackColor = System.Drawing.Color.Transparent;
            this.btn_QLTK.BorderColor = System.Drawing.Color.Transparent;
            this.btn_QLTK.BorderThickness = 1;
            this.btn_QLTK.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLTK.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLTK.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_QLTK.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_QLTK.FillColor = System.Drawing.Color.Transparent;
            this.btn_QLTK.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_QLTK.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_QLTK.Image = ((System.Drawing.Image)(resources.GetObject("btn_QLTK.Image")));
            this.btn_QLTK.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLTK.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_QLTK.Location = new System.Drawing.Point(-2, 209);
            this.btn_QLTK.Name = "btn_QLTK";
            this.btn_QLTK.Size = new System.Drawing.Size(213, 50);
            this.btn_QLTK.TabIndex = 9;
            this.btn_QLTK.Text = "Quản lý tài khoản";
            this.btn_QLTK.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLTK.Click += new System.EventHandler(this.btn_QLTK_Click);
            // 
            // btn_QLDV
            // 
            this.btn_QLDV.BackColor = System.Drawing.Color.Transparent;
            this.btn_QLDV.BorderColor = System.Drawing.Color.Transparent;
            this.btn_QLDV.BorderThickness = 1;
            this.btn_QLDV.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLDV.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLDV.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_QLDV.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_QLDV.FillColor = System.Drawing.Color.Transparent;
            this.btn_QLDV.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_QLDV.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_QLDV.Image = ((System.Drawing.Image)(resources.GetObject("btn_QLDV.Image")));
            this.btn_QLDV.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLDV.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_QLDV.Location = new System.Drawing.Point(-2, 107);
            this.btn_QLDV.Name = "btn_QLDV";
            this.btn_QLDV.Size = new System.Drawing.Size(213, 50);
            this.btn_QLDV.TabIndex = 8;
            this.btn_QLDV.Text = "Quản lý dịch vụ";
            this.btn_QLDV.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLDV.Click += new System.EventHandler(this.btn_QLDV_Click);
            // 
            // btn_DangXuat
            // 
            this.btn_DangXuat.BackColor = System.Drawing.Color.Transparent;
            this.btn_DangXuat.BorderColor = System.Drawing.Color.Transparent;
            this.btn_DangXuat.BorderThickness = 2;
            this.btn_DangXuat.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_DangXuat.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_DangXuat.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_DangXuat.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_DangXuat.FillColor = System.Drawing.Color.Transparent;
            this.btn_DangXuat.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_DangXuat.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_DangXuat.Image = ((System.Drawing.Image)(resources.GetObject("btn_DangXuat.Image")));
            this.btn_DangXuat.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_DangXuat.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_DangXuat.Location = new System.Drawing.Point(-2, 658);
            this.btn_DangXuat.Name = "btn_DangXuat";
            this.btn_DangXuat.Size = new System.Drawing.Size(213, 41);
            this.btn_DangXuat.TabIndex = 7;
            this.btn_DangXuat.Text = "Đăng xuất";
            this.btn_DangXuat.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_DangXuat.Click += new System.EventHandler(this.btn_DangXuat_Click);
            // 
            // guna2Button1
            // 
            this.guna2Button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2Button1.BorderColor = System.Drawing.Color.Transparent;
            this.guna2Button1.BorderThickness = 1;
            this.guna2Button1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button1.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button1.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.guna2Button1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.guna2Button1.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button1.Image")));
            this.guna2Button1.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button1.ImageSize = new System.Drawing.Size(30, 30);
            this.guna2Button1.Location = new System.Drawing.Point(-2, 5);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.Size = new System.Drawing.Size(213, 50);
            this.guna2Button1.TabIndex = 1;
            this.guna2Button1.Text = "Chăm sóc cư dân";
            this.guna2Button1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // btn_QLTI
            // 
            this.btn_QLTI.BackColor = System.Drawing.Color.Transparent;
            this.btn_QLTI.BorderColor = System.Drawing.Color.Transparent;
            this.btn_QLTI.BorderThickness = 1;
            this.btn_QLTI.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLTI.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLTI.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_QLTI.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_QLTI.FillColor = System.Drawing.Color.Transparent;
            this.btn_QLTI.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_QLTI.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_QLTI.Image = ((System.Drawing.Image)(resources.GetObject("btn_QLTI.Image")));
            this.btn_QLTI.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLTI.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_QLTI.Location = new System.Drawing.Point(-2, 56);
            this.btn_QLTI.Name = "btn_QLTI";
            this.btn_QLTI.Size = new System.Drawing.Size(213, 50);
            this.btn_QLTI.TabIndex = 2;
            this.btn_QLTI.Text = "Quản lý tiện ích";
            this.btn_QLTI.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLTI.Click += new System.EventHandler(this.btn_QLTI_Click);
            // 
            // btn_QLCP
            // 
            this.btn_QLCP.BackColor = System.Drawing.Color.Transparent;
            this.btn_QLCP.BorderColor = System.Drawing.Color.Transparent;
            this.btn_QLCP.BorderThickness = 1;
            this.btn_QLCP.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLCP.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLCP.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_QLCP.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_QLCP.FillColor = System.Drawing.Color.Transparent;
            this.btn_QLCP.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_QLCP.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_QLCP.Image = ((System.Drawing.Image)(resources.GetObject("btn_QLCP.Image")));
            this.btn_QLCP.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLCP.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_QLCP.Location = new System.Drawing.Point(-2, 311);
            this.btn_QLCP.Name = "btn_QLCP";
            this.btn_QLCP.Size = new System.Drawing.Size(213, 50);
            this.btn_QLCP.TabIndex = 5;
            this.btn_QLCP.Text = "Quản lý khoản phí";
            this.btn_QLCP.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLCP.Click += new System.EventHandler(this.btn_QLCP_Click);
            // 
            // btn_QLCH
            // 
            this.btn_QLCH.BackColor = System.Drawing.Color.Transparent;
            this.btn_QLCH.BorderColor = System.Drawing.Color.Transparent;
            this.btn_QLCH.BorderThickness = 1;
            this.btn_QLCH.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLCH.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLCH.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_QLCH.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_QLCH.FillColor = System.Drawing.Color.Transparent;
            this.btn_QLCH.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_QLCH.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_QLCH.Image = ((System.Drawing.Image)(resources.GetObject("btn_QLCH.Image")));
            this.btn_QLCH.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLCH.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_QLCH.Location = new System.Drawing.Point(-2, 158);
            this.btn_QLCH.Name = "btn_QLCH";
            this.btn_QLCH.Size = new System.Drawing.Size(213, 50);
            this.btn_QLCH.TabIndex = 3;
            this.btn_QLCH.Text = "Quản lý căn hộ";
            this.btn_QLCH.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLCH.Click += new System.EventHandler(this.btn_QLCH_Click);
            // 
            // btn_QLCDDD
            // 
            this.btn_QLCDDD.BackColor = System.Drawing.Color.Transparent;
            this.btn_QLCDDD.BorderColor = System.Drawing.Color.Transparent;
            this.btn_QLCDDD.BorderThickness = 1;
            this.btn_QLCDDD.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLCDDD.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_QLCDDD.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_QLCDDD.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_QLCDDD.FillColor = System.Drawing.Color.Transparent;
            this.btn_QLCDDD.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_QLCDDD.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_QLCDDD.Image = ((System.Drawing.Image)(resources.GetObject("btn_QLCDDD.Image")));
            this.btn_QLCDDD.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLCDDD.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_QLCDDD.Location = new System.Drawing.Point(-2, 260);
            this.btn_QLCDDD.Name = "btn_QLCDDD";
            this.btn_QLCDDD.Size = new System.Drawing.Size(213, 50);
            this.btn_QLCDDD.TabIndex = 4;
            this.btn_QLCDDD.Text = "Quản lý cư dân đại diện";
            this.btn_QLCDDD.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_QLCDDD.Click += new System.EventHandler(this.btn_QLCP_Click);
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox1.ErrorImage")));
            this.guna2PictureBox1.Image = global::ĐỒ_ÁN.Properties.Resources.logo;
            this.guna2PictureBox1.ImageRotate = 0F;
            this.guna2PictureBox1.Location = new System.Drawing.Point(220, 5);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.Size = new System.Drawing.Size(60, 38);
            this.guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox1.TabIndex = 85;
            this.guna2PictureBox1.TabStop = false;
            // 
            // ChamSocCuDan
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.ClientSize = new System.Drawing.Size(1311, 699);
            this.Controls.Add(this.guna2PictureBox1);
            this.Controls.Add(this.guna2GradientPanel2);
            this.Controls.Add(this.guna2GradientPanel1);
            this.Controls.Add(this.guna2GradientPanel8);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.guna2GradientPanel3);
            this.Controls.Add(this.guna2GradientPanel5);
            this.Controls.Add(this.dgv_KhieuNai);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ChamSocCuDan";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Chăm sóc cư dân";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.ChamSocCuDan_FormClosed);
            this.Load += new System.EventHandler(this.ChamSocCuDan_Load);
            this.guna2GradientPanel3.ResumeLayout(false);
            this.guna2GradientPanel5.ResumeLayout(false);
            this.guna2GradientPanel5.PerformLayout();
            this.guna2GradientPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_KhieuNai)).EndInit();
            this.guna2GradientPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Guna.UI2.WinForms.Guna2Button btn_PhanHoi;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel3;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel4;
        private Guna.UI2.WinForms.Guna2TextBox txt_keyword;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2ComboBox cbb_LoaiKhieuNai;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel5;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel2;
        private Guna.UI2.WinForms.Guna2Button btn_PhanCong;
        private System.Windows.Forms.DataGridView dgv_KhieuNai;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel6;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel8;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel1;
        private Guna.UI2.WinForms.Guna2Button btn_QLTK;
        private Guna.UI2.WinForms.Guna2Button btn_QLDV;
        private Guna.UI2.WinForms.Guna2Button btn_DangXuat;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2Button btn_QLTI;
        private Guna.UI2.WinForms.Guna2Button btn_QLCP;
        private Guna.UI2.WinForms.Guna2Button btn_QLCH;
        private Guna.UI2.WinForms.Guna2Button btn_QLCDDD;
        private Guna.UI2.WinForms.Guna2Button btn_Refresh;
        private Guna.UI2.WinForms.Guna2Button btn_TraCuu;
        private Guna.UI2.WinForms.Guna2Button btn_TB;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
    }
}